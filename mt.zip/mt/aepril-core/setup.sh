#!/bin/bash

# Check for --clean argument
if [ "$1" = "--clean" ]; then
    if [ -e .setup_done ]; then
        rm -rf libjson-rpc-cpp/* PcapPlusPlus/* PF_RING/* ObjectBox/* .setup_done
        git submodule foreach --recursive git reset --hard
        echo "Library folders cleaned. You can now run $0 again to redownload and recompile libraries for this project."
    else
        echo "Nothing to clean! You can run $0 again to download and compile libraries for this project."
    fi
    exit
fi

# Exit if setup is already done and not cleaning
if [ -e .setup_done ]; then
    echo "Setup already done, execute $0 --clean if you want to revert to a fresh state."
    exit
fi

# Check for incorrect arguments
if [ "$#" -ne 0 ]; then
    echo "Usage:"
    echo "$0           : Perform initial download and compilation of project submodules"
    echo "or"
    echo "$0 --clean   : Clean project submodules to a fresh state so they can be compiled again"
    exit
fi

# Update and initialize submodules
git submodule update --init --recursive

# PF_RING setup
cd PF_RING
git fetch --tags
git checkout tags/8.0.0
cd kernel
make
cd ../userland
./configure
make
cd ../..

# PcapPlusPlus setup
cd PcapPlusPlus
git fetch --tags
git checkout tags/v22.05
./configure-linux.sh --pf-ring --pf-ring-home $(pwd)/../PF_RING
make libs
cd ..

# libjson-rpc-cpp setup
mkdir -p libjson-rpc-cpp/build
cd libjson-rpc-cpp
git fetch --tags
git checkout tags/v1.4.1
cd build
cmake .. -DCOMPILE_TESTS=NO -DCOMPILE_EXAMPLES=NO -DHTTP_SERVER=YES -DHTTP_CLIENT=YES -DREDIS_SERVER=NO -DREDIS_CLIENT=NO -DUNIX_DOMAIN_SOCKET_SERVER=YES -DUNIX_DOMAIN_SOCKET_CLIENT=YES -DFILE_DESCRIPTOR_SERVER=YES -DFILE_DESCRIPTOR_CLIENT=YES -DTCP_SOCKET_SERVER=YES -DTCP_SOCKET_CLIENT=YES
make
make install
ldconfig 
cd ../..

# ObjectBox setup
bash <(curl -s https://raw.githubusercontent.com/objectbox/objectbox-c/main/download.sh) --quiet
download_dir="download"
target_dir="ObjectBox"

if [ ! -d "$download_dir" ]; then
    echo "Download directory does not exist."
    exit 1
fi

subdir=$(find "$download_dir" -mindepth 1 -maxdepth 1 -type d)

if [ -z "$subdir" ]; then
    echo "Subdirectory not found inside the download directory."
    exit 1
fi

mkdir -p "$target_dir"

for dir in include info lib; do
    if [ -d "${subdir}/${dir}" ]; then
        mv "${subdir}/${dir}" "${target_dir}/"
    fi
done

rm -rf download lib

# FlatBuffers setup
NAME="flatbuffers"
REPO="google/$NAME"
BRANCH="master"
DIR="include"
URL="https://github.com/$REPO/archive/$BRANCH.zip"
curl -L -o repo.zip "$URL"
unzip -j "repo.zip" "$NAME-$BRANCH/$DIR/*" -d "$target_dir/$DIR/$NAME/"

rm repo.zip

# Final steps
mkdir -p build
touch .setup_done
chmod -R 0777 .

echo "Setup done."