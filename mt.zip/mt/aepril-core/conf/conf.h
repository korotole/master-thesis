#ifndef AEPRIL_CORE_CONFIGURATION
#define AEPRIL_CORE_CONFIGURATION

//! ObjectBox Configuration
#define OBX_DIRECTORY "db" // Directory for ObjectBox database
// #define OBX_CLEAR_FILES          // Uncomment to clear ObjectBox files on startup

//! Logical Modules
#define PACKET_RULE_MATCH // Enable packet rule matching
#define PDU_MODIFICATION  // Enable PDU modification
#define PACKET_RESEND     // Enable packet resend functionality
#define HTTP_SERVER       // Enable HTTP server functionality

//! Logging Configuration
#define CONSOLE_LOGGING // Enable logging to the console
#define FILE_LOGGING    // Enable logging to a file

//! Logging Levels (uncomment to disable specific log levels)
#define DEBUG_LOGS_DISABLED // Disable debug logs
// #define INFO_LOGS_DISABLED       // Disable info logs
#define WARNING_LOGS_DISABLED    // Disable warning logs
// #define ERROR_LOGS_DISABLED      // Disable error logs

//! PDU Processing Configuration
// #define PDU_SHORT_HEADERS         // Enable short header processing for PDUs
#define PDU_LONG_HEADERS       // Enable long header processing for PDUs
#define BZ_AUTO_INCREMENTATION // Make PDUs treated always as valid (not obsolete in terms of BZ)
// #define FCS_POLYNOMIAL 0xEDB88320   // Set polynomial for Frame Check Sequence calculation
#define AES_CMAC_BIT_NUM_TRUNC 24 // Number of bits mac is trancated to
#define AES_CMAC_SIGNIFICANCE 1   // 1 for MOST significance bits, 0 for LEAST significant bits
#define RULE_DEACTIVATION_EXTRA 1 // Extra time in miliseconds to cover processing & initialization delay

//! Measurement
#define CPU_CYCLES
#define EXEC_SPEED
#define PCKT_COUNT

#endif // AEPRIL_CORE_CONFIGURATION