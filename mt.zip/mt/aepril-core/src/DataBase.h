#pragma once
#define OBX_CPP_FILE

#include <mutex>
#include <shared_mutex>
#include <thread>
#include <objectbox.hpp>
#include "obx/objectbox-model.h"
#include "obx/Rule.obx.hpp"
#include "conf.h"
#include "FrameRule.h"
#include "EventLogger.h"

/*
 * The class below is an implementation of DataBase abstraction that wraps the basic container operations.
 * DataBase class is based upon ObjectBox framework.
 * It does NOT perform any *logical* checks; they must be handled manually by the user via provied API.
 */
class DataBase
{
public:
    // Deleted copy constructor and assignment operator.
    DataBase(const DataBase &) = delete;
    DataBase &operator=(DataBase &) = delete;

    // Static method to get the instance of the class.
    static DataBase &Instance()
    {
        static DataBase instance;
        return instance;
    }

    /*
     * Checks if database is empty at the moment
     */
    inline bool Empty() const
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            return ruleBox->isEmpty();
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    /*
     * Checks if a rule with specified id is stored in the database
     */
    inline bool Contains(size_t id) const
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            return ruleBox->contains(id);
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    inline size_t Add(const FrameRule &&rule)
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            return ruleBox->put(FrameRule::FrameRuleToRule(rule), OBXPutMode_INSERT);
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    /*
     * Updates the rule with specified id
     */
    inline size_t Update(const FrameRule &&rule)
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            return ruleBox->put(FrameRule::FrameRuleToRule(rule), OBXPutMode_UPDATE);
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    /*
     * Gets a single rule
     */
    inline const FrameRule Get(size_t id) const
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            return FrameRule::RuleToFrameRule(ruleBox->get(id));
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    /*
     * Gets a copy of all rules
     */
    inline const std::vector<FrameRule> Get() const
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            return FrameRule::RulesToFrameRules(ruleBox->getAll());
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    /*
     * Deletes a single rule with specified id
     */
    inline void Delete(size_t id)
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            ruleBox->remove(id);
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    /*
     * Erases all the rules from the database
     */
    inline void Clear()
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            ruleBox->removeAll();
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    /*
     * Sets the state for a specified rule (active / not active)
     */
    inline void Set(bool state, size_t id)
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            std::unique_ptr<Rule> retrievedRule = ruleBox->get(id);
            retrievedRule->status = state;
            ruleBox->put(*retrievedRule);
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    /*
     * Gets the number of rules that are currently active
     */
    int GetActiveRulesCount() const
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            return static_cast<int>(activeRuleQuery->count());
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    /*
     * Gets the first active rule (merely one existing assumed)
     */
    FrameRule GetFirstActiveRule() const
    {
        std::scoped_lock lock(dbMutex);
        try
        {   
            return FrameRule::RuleToFrameRule(activeRuleQuery->findFirst());
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

    /*
     * Gets all active rules
     */
    std::vector<FrameRule> GetAllActiveRules() const
    {
        std::scoped_lock lock(dbMutex);
        try
        {
            return FrameRule::RulesToFrameRules(activeRuleQuery->find());
        }
        catch (const std::exception &e)
        {
            LOG_ERROR(e.what());
            throw;
        }
    }

private:
    // Private constructor.
    DataBase() : initialized(false)
    {
        Initialize();
    }

    ~DataBase()
    {
        store->close();
#ifdef OBX_CLEAR_FILES
        store->removeDbFiles(OBX_DIRECTORY);
#endif // OBX_CLEAR_FILES
    }

    // Initialization method
    void Initialize()
    {
        std::scoped_lock lock(dbMutex);
        if (!initialized)
        {
            try
            {
                obx::Options options(create_obx_model());
                options.directory(OBX_DIRECTORY);
                store = std::make_unique<obx::Store>(options);
                ruleBox = std::make_unique<obx::Box<Rule>>(*store.get());
                activeRuleQuery = std::make_unique<obx::Query<Rule>>(ruleBox->query(Rule_::status.equals(true)).build());
                initialized = true;
            }
            catch (const std::exception &e)
            {
                LOG_ERROR(e.what());
                throw;
            }
        }
    }

    // Member variables
    std::unique_ptr<obx::Store> store;
    std::unique_ptr<obx::Box<Rule>> ruleBox;
    std::unique_ptr<obx::Query<Rule>> activeRuleQuery;
    bool initialized;
    mutable std::shared_mutex dbMutex; // a mutex for managing concurrency
};