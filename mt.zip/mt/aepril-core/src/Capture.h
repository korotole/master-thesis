#pragma once

#include "IStrategy.h"
#include "Utilities.h"

class Capture
{
public:
    /**
     * @brief Capture thread arguments.
     *
     * Structure containing all the necessary information for packet processing.
     */
    struct CptrThrdArgs
    {
        std::vector<std::unique_ptr<stgy::IStrategy>> strategies;
        pcpp::PfRingDevice *dstIface;
        utils::SharedResource<bool> operCmd;
#ifdef PCKT_COUNT
        utils::SharedResource<uint64_t> pcktCntr;

        CptrThrdArgs() : dstIface(NULL), operCmd(false), pcktCntr(0) {}
#else
        CptrThrdArgs() : dstIface(NULL), operCmd(false) {}
#endif //PCKT_COUNT
    };

    /**
     * @brief A function ehich is called each time packet(s) arrived on some thread.
     * 
     * General packet processing logic.
     * 
     * @param packets Pointer to the array of raw packets arrived.
     * @param numOfPackets Number of packets arrived.
     * @param threadId The id of a thread that received the packets.
     * @param device The device (interface) the packets received from.
     * @param userCookie User arguments passed to the capture thread.
     */
    static void PacketArrived(pcpp::RawPacket *packets, uint32_t numOfPackets, uint8_t threadId, pcpp::PfRingDevice *device, void *userCookie)
    {

#ifdef EXEC_SPEED
        auto _time_start = std::chrono::high_resolution_clock::now();
#endif //EXEC_SPEED


#ifdef CPU_CYCLES
        uint64_t _cpu_a = __builtin_ia32_rdtsc();
#endif //CPU_CYCLES


#ifdef PCKT_COUNT
        LOG_INFO("Thread " + std::to_string(threadId) + ": " + std::to_string(numOfPackets) + " packet(s) arrived.");
#endif //PCKT_COUNT

        bool actStgyPresent = false;
        // LOG_DEBUG(std::to_string(numOfPackets) + " packet(s) arrived on thread " + std::to_string(threadId) + ".");
        CptrThrdArgs *args = (CptrThrdArgs *)userCookie;

        //! no operation desired at the moment, STOP scenario
        if (!args->operCmd.Read())
        {
            // resending all packets at once
            args->dstIface->sendPackets(packets, numOfPackets);


#ifdef CPU_CYCLES
            uint64_t _cpu_b = __builtin_ia32_rdtsc();
            __attribute__((unused)) const uint64_t _cpu_res = _cpu_b - _cpu_a;
            LOG_INFO("Thread " + std::to_string(threadId) + ": " + std::to_string(_cpu_res) + " cpu cycles.");
#endif //CPU_CYCLES


#ifdef EXEC_SPEED
            auto _time_stop = std::chrono::high_resolution_clock::now();
            __attribute__((unused)) const auto _time_res = std::chrono::duration_cast<std::chrono::nanoseconds>(_time_stop - _time_start);
            LOG_INFO("Thread " + std::to_string(threadId) + ": " + std::to_string(_time_res.count()) + " ns.");
#endif //EXEC_SPEED


#ifdef PCKT_COUNT
            args->pcktCntr.Write(args->pcktCntr.Read() + numOfPackets);
            LOG_INFO("Thread " + std::to_string(threadId) + ": " + std::to_string(args->pcktCntr.Read()) + " packets processed in total.");
#endif //PCKT_COUNT

            LOG_DEBUG("Thread " + std::to_string(threadId) + ": " + "No active strategies present, acting in transparent gateway mode.")

            return;
        }

        auto pckt_idx = args->pcktCntr.Read();
        //! START was pressed, process packets one by one
        for (uint32_t i = 0; i < numOfPackets; i++)
        {
            // parse packet
            pcpp::Packet packet(&packets[i]);
            pcpp::Layer *ethLayer = packet.getFirstLayer();
            pcpp::Layer *vlanLayer = ethLayer->getNextLayer();

            if (ethLayer->getProtocol() != pcpp::Ethernet && vlanLayer->getProtocol() != pcpp::VLAN)
            {   
                LOG_DEBUG("Thread " + std::to_string(threadId) + ": " + "Not an ethernet packet.");
                continue; // skip packet (leave it as it is)
            }

            pcpp::Layer *ipLayer = vlanLayer->getNextLayer();

            if (ipLayer == nullptr || ipLayer->getProtocol() != pcpp::IPv6)
            {
                LOG_DEBUG("Thread " + std::to_string(threadId) + ": " + "Not an IPv6 packet.");
                continue; // skip packet (leave it as it is)
            }

            //! process the packet with active rules
            for (auto &strategy : args->strategies)
            {
                if (strategy.get()->IsActive())
                {   
                    LOG_INFO("Thread " + std::to_string(threadId) + ": " + "executing strategy for rule " + std::to_string(strategy.get()->GetRuleId()) + ".");
                    strategy.get()->Execute(&packet, threadId, pckt_idx+1);
                    actStgyPresent = true;
                }
            }
            //! no active strategies present, enable STOP scenario
            if(!actStgyPresent)
            {
                args->operCmd.Write(false);
            }
        }
        // resending all packets at once
        args->dstIface->sendPackets(packets, numOfPackets);


#ifdef CPU_CYCLES
        uint64_t _cpu_b = __builtin_ia32_rdtsc();
        __attribute__((unused)) const uint64_t _cpu_res = _cpu_b - _cpu_a;
        LOG_INFO("Thread " + std::to_string(threadId) + ": " + std::to_string(_cpu_res) + " cpu cycles.");
#endif //CPU_CYCLES


#ifdef EXEC_SPEED
        auto _time_stop = std::chrono::high_resolution_clock::now();
        __attribute__((unused)) const auto _time_res = std::chrono::duration_cast<std::chrono::nanoseconds>(_time_stop - _time_start);
        LOG_INFO("Thread " + std::to_string(threadId) + ": " + std::to_string(_time_res.count()) + " ns.");
#endif //EXEC_SPEED


#ifdef PCKT_COUNT
        args->pcktCntr.Write(args->pcktCntr.Read() + numOfPackets);
        LOG_INFO("Thread " + std::to_string(threadId) + ": " + std::to_string(args->pcktCntr.Read()) + " packets processed in total.");
#endif //PCKT_COUNT

    }
};
