#include "BaseServer.h"

Json::Value BaseServer::UPSERT(int bz_length, int bz_start_bit, int crc_length, int crc_start_bit, const std::string &dest_ip, int dest_port, int duration, const std::string &duration_type, int id, int mac_length, int mac_start_bit, bool mode, int new_value, int pdu_id, const Json::Value &polynomial, bool protocol, const Json::Value &secret_key, int signal_length, const std::string &signal_name, int signal_start_bit, const std::string &src_ip, int src_port, bool status)
{
    Json::Value res(Json::objectValue);
    static const Json::StaticString _id("id");
    static const Json::StaticString _message("message");

    if (id == 0) //* insert a new rule
    {
        // convert the polynomial from Json::Value to std::vector<uint8_t>
        std::vector<uint8_t> poly;
        for (uint8_t i = 0; i < polynomial.size(); i++)
        {
            poly.emplace_back((uint8_t)polynomial[i].asUInt());
        }

        // convert mac to vector
        std::vector<uint8_t> key;
        for (uint8_t i = 0; i < secret_key.size(); i++)
        {
            key.emplace_back((uint8_t)secret_key[i].asUInt());
        }

        res[_id] = (int)DataBase::Instance().Add(FrameRule(
            0,  //! new rule always must have id equal to 0
            bz_length,
            bz_start_bit,
            crc_length,
            crc_start_bit,
            dest_ip,
            dest_port,
            duration,
            duration_type,
            mac_length,
            mac_start_bit,
            mode,
            new_value,
            pdu_id,
            poly,
            protocol,
            key,
            signal_length,
            signal_name,
            signal_start_bit,
            src_ip,
            src_port,
            status));
        res[_message] = "A rule was ADDED successfully.";

        LOG_INFO("Rule " + res[_id].asString() + " was ADDED successfully.");
    }
    else if (DataBase::Instance().Contains((size_t)id)) //* update the existing rule
    {
        // convert the polynomial from Json::Value to std::vector<uint8_t>
        std::vector<uint8_t> poly;
        for (uint8_t i = 0; i < polynomial.size(); i++)
        {
            poly.emplace_back((uint8_t)polynomial[i].asUInt());
        }

        // convert mac to vector
        std::vector<uint8_t> key;
        for (uint8_t i = 0; i < secret_key.size(); i++)
        {
            key.emplace_back((uint8_t)secret_key[i].asUInt());
        }

        res[_id] = (int)DataBase::Instance().Update(FrameRule(
            id, //! use the provided rule id
            bz_length,
            bz_start_bit,
            crc_length,
            crc_start_bit,
            dest_ip,
            dest_port,
            duration,
            duration_type,
            mac_length,
            mac_start_bit,
            mode,
            new_value,
            pdu_id,
            poly,
            protocol,
            key,
            signal_length,
            signal_name,
            signal_start_bit,
            src_ip,
            src_port,
            status));
        res[_message] = "A rule was UPDATED successfully.";

        LOG_INFO("Rule " + res[id].asString() + " was UPDATED successfully.");
    }
    else // the requested rule to update does not exist, throw an exception -> returns error object
    {
        LOG_WARNING("No rule to UPDATE with id " + std::to_string(id) + " exists.");
        throw jsonrpc::JsonRpcException(err::E_UPDATE_NO_ID_FOUND, err::Error<err::RpcError>::Instance().ToString(err::E_UPDATE_NO_ID_FOUND));
    }

    return res;
}

Json::Value BaseServer::SET(int id, bool status)
{
    Json::Value res(Json::objectValue);
    static const Json::StaticString _res("res");
    static const Json::StaticString _message("message");

    if (DataBase::Instance().Contains((size_t)id)) // change a state of the rule specified
    {
        DataBase::Instance().Set(status, (size_t)id);
    }
    else // no rule specified exists, impossible to change a state, throw an exception
    {
        LOG_WARNING("No rule to SET state with id " + std::to_string(id) + " exists.");
        throw jsonrpc::JsonRpcException(err::E_SET_NO_ID_FOUND, err::Error<err::RpcError>::Instance().ToString(err::E_SET_NO_ID_FOUND));
    }

    res[_res] = true;
    res[_message] = "Status of rule " + std::to_string(id) + " set to " + std::to_string(status) + " successfully.";

    return res;
}

Json::Value BaseServer::GET(int id)
{
    Json::Value res(Json::arrayValue);

    if (DataBase::Instance().Empty()) // no rules are stored, nothing to get
    {
        LOG_WARNING("Database of rules is EMPTY, no rules to GET.");
        throw jsonrpc::JsonRpcException(err::E_GET_DATABASE_EMPTY, err::Error<err::RpcError>::Instance().ToString(err::E_GET_DATABASE_EMPTY));
    }
    else if (id == -1) // pass an array of all frame rules to the response object
    {
        for (auto r : DataBase::Instance().Get())
        {
            res.append(ConstructFrameRuleObj(r));
        }
    }
    else if (DataBase::Instance().Contains((size_t)id)) // pass the requested frame rule to the response object
    {
        res.append(ConstructFrameRuleObj(DataBase::Instance().Get((size_t)id)));
    }
    else // no frame rule with the specified id exists, throw an exception -> returns error object
    {
        LOG_WARNING("No rule to GET with id " + std::to_string(id) + " exists.");
        throw jsonrpc::JsonRpcException(err::E_GET_NO_ID_FOUND, err::Error<err::RpcError>::Instance().ToString(err::E_GET_NO_ID_FOUND));
    }

    return res;
}

Json::Value BaseServer::DELETE(int id)
{
    Json::Value res(Json::objectValue);
    static const Json::StaticString _res("res");
    static const Json::StaticString _message("message");

    if (DataBase::Instance().Empty()) // no rules are stored, nothing to delete
    {
        LOG_WARNING("Database of rules is EMPTY, no rules to DELETE.");
        throw jsonrpc::JsonRpcException(err::E_DELETE_DATABASE_EMPTY, err::Error<err::RpcError>::Instance().ToString(err::E_DELETE_DATABASE_EMPTY));
    }
    else if (id == -1) // pass an array of all frame rules to the response object
    {
        DataBase::Instance().Clear();
    }
    else if (DataBase::Instance().Contains((size_t)id)) // pass the requested frame rule to the response object
    {
        DataBase::Instance().Delete((size_t)id);
    }
    else // no frame rule with the specified id exists, throw an exception -> returns error object
    {
        LOG_WARNING("No rule to DELETE with id " + std::to_string(id) + " exists.");
        throw jsonrpc::JsonRpcException(err::E_DELETE_NO_ID_FOUND, err::Error<err::RpcError>::Instance().ToString(err::E_DELETE_NO_ID_FOUND));
    }

    res[_res] = true;
    res[_message] = "Rule " + std::to_string(id) + " deleted successfully.";

    return res;
}

Json::Value BaseServer::START(void)
{
    Json::Value res(Json::objectValue);
    static const Json::StaticString _res("res");
    static const Json::StaticString _message("message");

    if (!DataBase::Instance().GetActiveRulesCount()) // no active rules present
    {
        LOG_WARNING("Database contains no active rules, START is not possible.");
        throw jsonrpc::JsonRpcException(err::E_START_NO_ACTIVE_RULES, err::Error<err::RpcError>::Instance().ToString(err::E_START_NO_ACTIVE_RULES));
    }

    auto rules = DataBase::Instance().GetAllActiveRules();
    mCptrCntl->strategies.clear();
       
    for (auto r : rules)
    {
        mCptrCntl->strategies.emplace_back(std::move((stgy::StgyMngr::CreateStrategy(r))));
    }

    mCptrCntl->operCmd.Write(true);
    LOG_INFO("TRAFFIC INTERFERENCE STARTED: number of active rules: " + std::to_string(DataBase::Instance().GetActiveRulesCount()) + ".");

    try
    {   
        //! apply all the strategies
    }
    catch (std::exception &e)
    {
        LOG_ERROR(e.what());
        throw jsonrpc::JsonRpcException(err::E_UNKOWN, e.what());
    }

    res[_res] = true;
    res[_message] = "Switched to traffic interference mode, number of active strategies: " + std::to_string(mCptrCntl->strategies.size()) + ".";

    return res;    
}

Json::Value BaseServer::STOP(void)
{
    Json::Value res(Json::objectValue);
    static const Json::StaticString _res("res");
    static const Json::StaticString _message("message");

    if (!mCptrCntl->operCmd.Read()) // no rule application at the moment
    {
        LOG_WARNING("Traffic interference is not in progress.");
        throw jsonrpc::JsonRpcException(err::E_STOP_NO_ACTIVE_RULES, err::Error<err::RpcError>::Instance().ToString(err::E_STOP_NO_ACTIVE_RULES));
    }

    try
    {   
        //! apply all the strategies
        mCptrCntl->operCmd.Write(false);
        mCptrCntl->strategies.clear(); 
        LOG_DEBUG("STOPPED");
    }
    catch (std::exception &e)
    {
        LOG_ERROR(e.what());
        throw jsonrpc::JsonRpcException(err::E_UNKOWN, e.what());
    }

    res[_res] = true;
    res[_message] = "Switched to transparent gateway mode.";

    return res;    
}

Json::Value BaseServer::TEST(void)
{
    Json::Value res(Json::objectValue);
    static const Json::StaticString _res("res");
    static const Json::StaticString _message("message");

    if(mCptrCntl->operCmd.Read())
    {
        res[_res] = true;
        res[_message] = "Traffic interference is in progress.";
    }
    else
    {
        res[_res] = false;
        res[_message] = "Traffic interference is not in progress, acting in transparent gateway mode.";
    }

    return res;
}

Json::Value BaseServer::ConstructFrameRuleObj(const FrameRule &frameRule)
{
    Json::Value frameRuleObj(Json::objectValue);

    frameRuleObj["id"] = static_cast<Json::Int64>(frameRule.id);
    frameRuleObj["bz_length"] = frameRule.bz_length;
    frameRuleObj["bz_start_bit"] = frameRule.bz_start_bit;
    frameRuleObj["crc_length"] = frameRule.crc_length;
    frameRuleObj["crc_start_bit"] = frameRule.crc_start_bit;
    frameRuleObj["dest_ip"] = frameRule.dest_ip;
    frameRuleObj["dest_port"] = frameRule.dest_port;
    frameRuleObj["duration"] = frameRule.duration;
    frameRuleObj["duration_type"] = frameRule.duration_type;
    frameRuleObj["mac_length"] = frameRule.mac_length;
    frameRuleObj["mac_start_bit"] = frameRule.mac_start_bit;
    frameRuleObj["mode"] = frameRule.mode;
    frameRuleObj["new_value"] = static_cast<Json::UInt64>(frameRule.new_value);
    frameRuleObj["pdu_id"] = frameRule.pdu_id;
    frameRuleObj["protocol"] = frameRule.protocol;
    frameRuleObj["signal_length"] = frameRule.signal_length;
    frameRuleObj["signal_name"] = frameRule.signal_name;
    frameRuleObj["signal_start_bit"] = frameRule.signal_start_bit;
    frameRuleObj["src_ip"] = frameRule.src_ip;
    frameRuleObj["src_port"] = frameRule.src_port;
    frameRuleObj["status"] = frameRule.status;

    // Handle polynomial
    for (size_t i = 0; i < frameRule.polynomial.size(); ++i) {
        frameRuleObj["polynomial"][static_cast<int>(i)] = frameRule.polynomial[i];
    }

    // Handle secret_key
    for (size_t i = 0; i < frameRule.secret_key.size(); ++i) {
        frameRuleObj["secret_key"][static_cast<int>(i)] = frameRule.secret_key[i];
    }

    return frameRuleObj;
}