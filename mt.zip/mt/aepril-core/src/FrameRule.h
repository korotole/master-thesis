#pragma once 

#include <cstdint>
#include <string>
#include <vector>
#include "common/EventLogger.h"
#include "Utilities.h"
#include "obx/Rule.obx.hpp"

class FrameRule
{
public:
    int64_t id;
    int8_t bz_length;
    int16_t bz_start_bit;
    int8_t crc_length;
    int16_t crc_start_bit;
    std::string dest_ip;
    int32_t dest_port;
    int32_t duration;
    std::string duration_type;
    int8_t mac_length;
    int16_t mac_start_bit;
    bool mode;
    uint64_t new_value;
    int16_t pdu_id;
    std::vector<uint8_t> polynomial;
    bool protocol;
    std::vector<uint8_t> secret_key;
    int16_t signal_length;
    std::string signal_name;
    int16_t signal_start_bit;
    std::string src_ip;
    int32_t src_port;
    bool status;

    FrameRule(
        int64_t id,
        int8_t bz_length,
        int16_t bz_start_bit,
        int8_t crc_length,
        int16_t crc_start_bit,
        std::string dest_ip,
        int32_t dest_port,
        int32_t duration,
        std::string duration_type,
        int8_t mac_length,
        int16_t mac_start_bit,
        bool mode,
        uint64_t new_value,
        int16_t pdu_id,
        std::vector<uint8_t> polynomial,
        bool protocol,
        std::vector<uint8_t> secret_key,
        int16_t signal_length,
        std::string signal_name,
        int16_t signal_start_bit,
        std::string src_ip,
        int32_t src_port,
        bool status)
        : id(id),
          bz_length(bz_length),
          bz_start_bit(bz_start_bit),
          crc_length(crc_length),
          crc_start_bit(crc_start_bit),
          dest_ip(dest_ip),
          dest_port(dest_port),
          duration(duration),
          duration_type(duration_type),
          mac_length(mac_length),
          mac_start_bit(mac_start_bit),
          mode(mode),
          new_value(new_value),
          pdu_id(pdu_id),
          polynomial(polynomial),
          protocol(protocol),
          secret_key(secret_key),
          signal_length(signal_length),
          signal_name(signal_name),
          signal_start_bit(signal_start_bit),
          src_ip(src_ip),
          src_port(src_port),
          status(status)
    {
    }

    // Template function to convert FrameRule or unique_ptr<FrameRule> to Rule
    template <typename FrameRuleType>
    static Rule FrameRuleToRule(const FrameRuleType &fr)
    {
        const FrameRule *frameRulePtr;

        if constexpr (std::is_same_v<FrameRuleType, std::unique_ptr<FrameRule>>)
        {
            if (!fr)
            {
                throw std::invalid_argument("Unique pointer to FrameRule is null");
            }
            frameRulePtr = fr.get();
        }
        else
        {
            frameRulePtr = std::addressof(fr);
        }

        return Rule{
            frameRulePtr->id, //! id == 0 -> NEW object is created, else UPDATE
            frameRulePtr->bz_length,
            frameRulePtr->bz_start_bit,
            frameRulePtr->crc_length,
            frameRulePtr->crc_start_bit,
            frameRulePtr->dest_ip,
            frameRulePtr->dest_port,
            frameRulePtr->duration,
            frameRulePtr->duration_type,
            frameRulePtr->mac_length,
            frameRulePtr->mac_start_bit,
            frameRulePtr->mode,
            frameRulePtr->new_value,
            frameRulePtr->pdu_id,
            serializeVectorField(frameRulePtr->polynomial),
            frameRulePtr->protocol,
            serializeVectorField(frameRulePtr->secret_key),
            frameRulePtr->signal_length,
            frameRulePtr->signal_name,
            frameRulePtr->signal_start_bit,
            frameRulePtr->src_ip,
            frameRulePtr->src_port,
            frameRulePtr->status};
    }

    // Template function to convert Rule or unique_ptr<Rule> to FrameRule
    template <typename RuleType>
    static FrameRule RuleToFrameRule(const RuleType &rule)
    {
        const Rule *r;

        if constexpr (std::is_same_v<RuleType, std::unique_ptr<Rule>>)
        {
            if (!rule)
            {
                throw std::invalid_argument("Unique pointer to Rule is null");
            }
            r = rule.get();
        }
        else
        {
            r = std::addressof(rule);
        }

        return FrameRule(
            r->id,
            r->bz_length,
            r->bz_start_bit,
            r->crc_length,
            r->crc_start_bit,
            r->dest_ip,
            r->dest_port,
            r->duration,
            r->duration_type,
            r->mac_length,
            r->mac_start_bit,
            r->mode,
            r->new_value,
            r->pdu_id,
            deserializeVectorField(r->serialized_polynomial),
            r->protocol,
            deserializeVectorField(r->serialized_secret_key),
            r->signal_length,
            r->signal_name,
            r->signal_start_bit,
            r->src_ip,
            r->src_port,
            r->status);
    }

    // Template function to convert vector of Rule or unique_ptr<Rule> to vector of FrameRule
    template <typename RuleType>
    static std::vector<FrameRule> RulesToFrameRules(const std::vector<RuleType> &rules)
    {
        std::vector<FrameRule> frameRules;
        frameRules.reserve(rules.size());

        for (const auto &rule : rules)
        {
            frameRules.emplace_back(RuleToFrameRule(rule));
        }

        return frameRules;
    }

private:
    static std::string serializeVectorField(const std::vector<uint8_t> &field)
    {
        return utils::serializeVector(field);
    }

    static std::vector<uint8_t> deserializeVectorField(const std::string &fieldStr)
    {
        return utils::deserializeVector(fieldStr);
    }
};
