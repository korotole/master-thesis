#include "SystemLogic.h"

int SystemLogic::InitServer()
{
    int res = OK;

    try
    {
        this->connector = new jsonrpc::HttpServer(8383, "", "", 1);
        this->server = new BaseServer(*(this->connector), jsonrpc::JSONRPC_SERVER_V2, &mCaptureArgs);

        if (server->StartListening())
        {
            LOG_INFO("Server started successfully.");
        }
        else
        {
            LOG_ERROR(err::Error<err::LogicError>::Instance().ToString(err::E_HTTP_SERVER));
            res = err::E_HTTP_SERVER;
        }
    }
    catch (jsonrpc::JsonRpcException &e)
    {
        LOG_ERROR(e.what());
    }

    return res;
}

/**
 * @brief initialize application on startup
 *
 */
int SystemLogic::Initialize(int argc, char **argv)
{
    //* initialize pcpp application
    pcpp::AppName::init(argc, argv);

    //* initialize JSON RPC server
    auto result = InitServer();
    if (result != OK)
    {
        return result;
    }

    //* Open the PF_RING device in Rx multi-thread mode.
    //* Distribution of packets between threads will be done per-flow (as opposed to round-robin)
    if (masterIface != NULL && !masterIface->openMultiRxChannels(numOfCaptureThreads, pcpp::PfRingDevice::PerFlow))
    {
        LOG_ERROR(err::Error<err::LogicError>::Instance().ToString(err::E_OPENING_OF_RX_CHANNELS_FAILED_MASTER));
        return err::E_OPENING_OF_RX_CHANNELS_FAILED_MASTER;
    }

    //* Open the PF_RING device for Tx operations.
    if (slaveIface != NULL && !slaveIface->open())
    {
        LOG_ERROR(err::Error<err::LogicError>::Instance().ToString(err::E_OPENING_OF_SLAVE_IFACE));
        return err::E_OPENING_OF_SLAVE_IFACE;
    }

    return result;
}

/**
 * The callback to be called when application is terminated by ctrl-c.
 * Do cleanup and finish the program.
 */
void onApplicationInterrupted(void *cookie)
{
    bool *shouldStop = (bool *)cookie;
    *shouldStop = true;
    std::cout << std::endl;
    
    LOG_DEBUG("Application was interrupted.");
}

int SystemLogic::DoWork()
{
    bool shouldStop = false;
    //* register the on app close event
    pcpp::ApplicationEventHandler::getInstance().onApplicationInterrupted(onApplicationInterrupted, &shouldStop);

    //* prepare packet capture configuration
    mCaptureArgs.dstIface = slaveIface;

    //* setup capture
    pcpp::CoreMask coreMask = 0;
    int threadId = 0, threadCount = 0;

    //* mark only relevant cores by adding them to core mask
    while (threadCount < numOfCaptureThreads)
    {
        if (pcpp::SystemCores::IdToSystemCore[threadId].Id != masterIface->getCurrentCoreId().Id)
        {
            coreMask |= pcpp::SystemCores::IdToSystemCore[threadId].Mask;
            threadCount++;
        }

        threadId++;
    }

    //* start capturing packets on all threads
    if (!masterIface->startCaptureMultiThread(Capture::PacketArrived, &mCaptureArgs, coreMask))
    {
        LOG_ERROR(err::Error<err::LogicError>::Instance().ToString(err::E_CAPTURING_MASTER));
        return err::E_CAPTURING_MASTER;
    }

    //* infinite loop (until program is terminated)
    while (!shouldStop)
    {
        sleep(5);
    }

    return OK;
}

/**
 * Print application usage
 */
void SystemLogic::PrintUsage()
{
    std::cout << std::endl
              << "Usage:" << std::endl
              << "------" << std::endl
              << pcpp::AppName::get() << " [-hvl] {--master-interface INTERFACE_NAME}" << std::endl
              << "                    {--slave-interface INTERFACE_NAME}" << std::endl
              << "                    [-t NUM_OF_THREADS]" << std::endl
              << std::endl
              << "Options:" << std::endl
              << std::endl
              << "    -h|--help                                  : Displays this help message and exits" << std::endl
              << "    -l|--list-interfaces                       : Lists available Ethernet interfaces (with PF_RING) and exits" << std::endl
              << "    -m|--master-interface     INTERFACE_NAME   : The master Ethernet interface name (usually connected to HCP5)" << std::endl
              << "    -s|--slave-interface      INTERFACE_NAME   : The slave Ethernet interface name (usually connected to HCP2/ConMod/etc.)" << std::endl
              << "    -t|--num-of-threads       NUM_OF_THREADS   : Number of capture threads to open. Should be in" << std::endl
              << "                                                 the range of 1 to NUM_OF_CORES_ON_MACHINE-1." << std::endl
              << "                                                 Default is using all machine cores except the core" << std::endl
              << "                                                 the application is running on." << std::endl
              << std::endl;
}

/**
 * @brief Parses options provided via command line, performs further adjustments
 *
 * @param argc derived from main function
 * @param argv derived from main function
 * @return int: -1 if all is OK, 0 if all is OK and program is to be terminated and >0 if any errors
 */
int SystemLogic::ParseOptions(int argc, char **argv)
{
    LOG_DEBUG("Parsing options...");
    int exitValue = -1;

    int optionIndex = 0;
    int opt = 0;

    static struct option AeprilCoreLongOptions[] =
        {
            {"master-interface", required_argument, 0, 'm'},
            {"slave-interface", required_argument, 0, 's'},
            {"num-of-threads", required_argument, 0, 't'},
            {"help", no_argument, 0, 'h'},
            {"list-interfaces", no_argument, 0, 'l'},
            {0, 0, 0, 0}};
    constexpr auto AeprilCoreShortOptions = "t:hlm:s:";

    while ((opt = getopt_long(argc, argv, AeprilCoreShortOptions, AeprilCoreLongOptions, &optionIndex)) != -1)
    {
        switch (opt)
        {
        case 0:
        {
            break;
        }
        case 'm':
        {
            std::string ifaceName = std::string(optarg);
            masterIface = pcpp::PfRingDeviceList::getInstance().getPfRingDeviceByName(ifaceName);
            if (masterIface == nullptr)
            {
                LOG_ERROR(err::Error<err::LogicError>::Instance().ToString(err::E_NO_PFRING_DEV_MASTER) + " " + ifaceName);
                return err::E_NO_PFRING_DEV_MASTER;
            }
            break;
        }
        case 's':
        {
            std::string ifaceName = std::string(optarg);
            slaveIface = pcpp::PfRingDeviceList::getInstance().getPfRingDeviceByName(ifaceName);
            if (slaveIface == nullptr)
            {
                LOG_ERROR(err::Error<err::LogicError>::Instance().ToString(err::E_NO_PFRING_DEV_SLAVE) + " " + ifaceName);
                return err::E_NO_PFRING_DEV_SLAVE;
            }
            break;
        }
        case 't':
        {
            numOfCaptureThreads = atoi(optarg);
            if (numOfCaptureThreads < 1 || numOfCaptureThreads > totalNumOfCores - 1)
            {
                LOG_ERROR(err::Error<err::LogicError>::Instance().ToString(err::E_NUM_OF_CAPTURE_THREADS) + std::to_string(totalNumOfCores - 1));
                return err::E_NUM_OF_CAPTURE_THREADS;
            }
            break;
        }
        case 'h': // must exit
        {
            PrintUsage();
            exitValue = 0;
            break;
        }
        case 'l': // must exit
        {
            ListDevices();
            exitValue = 0;
            break;
        }
        default:
        {
            PrintUsage();
        }
        }
    }

    return exitValue;
}

int SystemLogic::CheckOptions()
{
    //* Sanity checks: require master interface (file) AND slave interface (file)
    if (masterIface == NULL)
    {
        LOG_ERROR(err::Error<err::LogicError>::Instance().ToString(err::E_NO_MASTER));
        return err::E_NO_MASTER;
    }
    if (slaveIface == NULL)
    {
        LOG_ERROR(err::Error<err::LogicError>::Instance().ToString(err::E_NO_SLAVE));
        return err::E_NO_SLAVE;
    }
    if (masterIface == slaveIface)
    {
        LOG_ERROR(err::Error<err::LogicError>::Instance().ToString(err::E_SAME_IFACE));
        return err::E_SAME_IFACE;
    }
    
    return 0;
}

void SystemLogic::ListDevices()
{
    //* suppress errors as there may be devices (like lo) that their MAC address can't be read, etc.
    pcpp::Logger::getInstance().suppressLogs();

    const std::vector<pcpp::PfRingDevice *> &devList = pcpp::PfRingDeviceList::getInstance().getPfRingDevicesList();
    for (std::vector<pcpp::PfRingDevice *>::const_iterator iter = devList.begin(); iter != devList.end(); iter++)
    {
        std::ostringstream interfaceIndex;
        if ((*iter)->getInterfaceIndex() <= 9999)
        {
            interfaceIndex << (*iter)->getInterfaceIndex();
        }
        else
        {
            interfaceIndex << "N/A";
        }

        std::cout
            << "    -> Name: " << std::left << std::setw(8) << (*iter)->getDeviceName()
            << " Index: " << std::setw(5) << interfaceIndex.str()
            << " MAC address: " << std::setw(19) << ((*iter)->getMacAddress() == pcpp::MacAddress::Zero ? "N/A" : (*iter)->getMacAddress().toString())
            << " Available RX channels: " << std::setw(3) << (int)(*iter)->getTotalNumOfRxChannels()
            << " MTU: " << (*iter)->getMtu()
            << std::endl;
    }

    //* re-enable errors
    pcpp::Logger::getInstance().enableLogs();
}