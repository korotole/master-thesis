#pragma once

#include <PcapPlusPlusVersion.h>
#include <PcapLiveDeviceList.h>
#include <SystemUtils.h>
#include <Logger.h>
#include <stdlib.h>
#include <getopt.h>
#include <sstream>
#include <unistd.h>
#include <string>
#include <thread>
#include <ostream>
#include <chrono>
#include "Capture.h"
#include "EventLogger.h"
#include "BaseServer.h"
#include "conf.h"

class SystemLogic
{
public:
    SystemLogic(int argc, char **argv)
    {
        auto res = ParseOptions(argc, argv);
        if (res != -1)
        {
            this->~SystemLogic();
            exit(res);
        }

        res = CheckOptions();
        if (res > 0)
        {
            this->~SystemLogic();
            exit(res);
        }
    }

    ~SystemLogic()
    {
        // stop capturing packets, close the device
        if (masterIface != NULL)
        {   
            masterIface->stopCapture();
            masterIface->close();
        }
        if (slaveIface != NULL)
        {
            slaveIface->stopCapture();
            slaveIface->close();
        }
        if (server != nullptr)
        {
            server->StopListening();
            delete this->server;
            delete this->connector;
        }
    }

    int Initialize(int argc, char **argv);
    int DoWork();

private:
    //! Capture arguments. strategies, START / STOP
    Capture::CptrThrdArgs mCaptureArgs;

    // HTTP server compounds
    jsonrpc::AbstractServerConnector *connector = nullptr;
    BaseServer *server = nullptr;

    // pcap dependencies
    pcpp::PfRingDevice *masterIface = nullptr; // interface to recieve data
    pcpp::PfRingDevice *slaveIface = nullptr;  // interface to send data to

    // thread count
    int totalNumOfCores = pcpp::getNumOfCores();
    int numOfCaptureThreads = totalNumOfCores - 1;

    /**
     * @brief 
     * 
     * @return int 
     */
    int InitServer();

    /**
     * @brief 
     * 
     * @param argc 
     * @param argv 
     * @return int 
     */
    int ParseOptions(int argc, char **argv);

    /**
     * @brief 
     * 
     * @return int 
     */
    int CheckOptions();

    /**
     * @brief 
     * 
     */
    void PrintUsage();

    /**
     * @brief Lists all available PF_RING devices
     * 
     */
    void ListDevices();
    
    // pcpp::IFileReaderDevice *masterFile = NULL;
    // pcpp::PcapNgFileWriterDevice *slaveFile = NULL;
};