#pragma once

#include <iostream>
#include <jsonrpccpp/server.h>
#include <jsonrpccpp/server/connectors/httpserver.h>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <string>
#include <vector>
#include "httpserver.h"
#include "rpc/rpcserver.h"
#include "Error.h"
#include "EventLogger.h"
#include "DataBase.h"
#include "FrameRule.h"
#include "Capture.h"
#include "StgyMngr.h"


/*
 * BaseServer is responsible for all logical operations covering the database access,
 * ADD, UPDATE, DELETE, SET, GET
 * Performs logical sanity checks and is capable of throwing logical exceptions.
 */
class BaseServer : public RpcServer
{
  public:
    BaseServer(jsonrpc::AbstractServerConnector &conn, jsonrpc::serverVersion_t type, Capture::CptrThrdArgs *args)
        : RpcServer(conn, type), mCptrCntl(args)
    {
    }

    /**
     * UPSERT a rule into the system.
     * This function triggers an insertion or update (hence "UPSERT") of a rule based on parameters.
     * If 'id' is > 0, the rule with such `id` is updated by sumbstitution of its parameters values with the new ones.
     * Else, new rule is triggered to be created.
     *
     * @param bz_length        The bit length of the BZ field (Freshness Value).
     * @param bz_start_bit     The starting bit position of the BZ field.
     * @param crc_length       The length of the CRC field.
     * @param crc_start_bit    The starting bit position of the CRC field.
     * @param dest_ip          The destination IP address.
     * @param dest_port        The destination port number.
     * @param duration         The duration for which the rule is valid.
     * @param duration_type    The type of duration ('cyc','ms','s','m','inf').
     * @param id               The unique identifier for the rule.
     * @param mac_length       The length of the MAC field.
     * @param mac_start_bit    The starting bit of the MAC.
     * @param mode             The mode of operation (traffic filtering (0), signal manipulation (1)).
     * @param new_value        The new signal value to be set.
     * @param pdu_id           The Protocol Data Unit (PDU) identifier.
     * @param polynomial       The polynomial used for CRC calculation.
     * @param protocol         The protocol to be used (true - TCP, false - UDP).
     * @param secret_key       The secret key used for encryption/decryption via AUTOSAR SecOC profile 2.
     * @param signal_length    The length of the signal.
     * @param signal_name      The name of the signal.
     * @param signal_start_bit The starting bit of the signal.
     * @param src_ip           The source IP address.
     * @param src_port         The source port number.
     * @param status           The status of the rule (true - active, false - inactive).
     *
     * @return Json::Value    A JSON object representing the result of the UPSERT operation.
     *
     * @note: Function performs no validation of the input parameters.
     * Ensure that the input parameters are correctly set before invoking this function.
     */
    Json::Value UPSERT(int bz_length, int bz_start_bit, int crc_length, int crc_start_bit, const std::string& dest_ip, int dest_port, int duration, const std::string& duration_type, int id, int mac_length, int mac_start_bit, bool mode, int new_value, int pdu_id, const Json::Value& polynomial, bool protocol, const Json::Value& secret_key, int signal_length, const std::string& signal_name, int signal_start_bit, const std::string& src_ip, int src_port, bool status);

    /**
     * SET the status of a specific rule.
     * This function is used to activate or deactivate a rule based on its unique identifier.
     *
     * @param id      The unique identifier of the manipulation rule (-1 for all).
     * @param status  The desired status of the rule (true - active, false - inactive).
     *
     * @return bool   Returns true if the operation was successful, false otherwise.
     */
    Json::Value  SET(int id, bool status);

    /**
     * GET information about a specific rule.
     * This function is used to pass the specified rule to client.
     *
     * @param id    The unique identifier of a rule (-1 for all).
     *
     * @return Json::Value  A JSON object representing the details of the manipulation rule.
     */
    Json::Value GET(int id);

    /**
     * DELETE a specific manipulation rule.
     * This function is used to remove a rule from the system.
     *
     * @param id   The unique identifier of rule to be deleted (-1 for all).
     *
     * @return bool  Returns true if the rule was successfully deleted, false if the rule did not exist or the deletion failed.
     */
    Json::Value  DELETE(int id);

    /**
     * START the operation of the system.
     * This function activates the rule processing mechanism in the system.
     *
     * @return bool  Returns true if the process was successfully started, false otherwise.
     */
    Json::Value  START(void);

    /**
     * STOP the operation of the system.
     * This function deactivates the rule processing mechanism in the system.
     *
     * @return bool  Returns true if the process was successfully stopped, false otherwise.
     */
    Json::Value  STOP(void);

    /**
     * TEST the connection between the client and server.
     * This function is used to provide a feedback of successful connection to the client.
     *
     * @return bool  Returns true
     */
    Json::Value  TEST(void);

  private:
    /**
     * Construct a Json::Value object from the FrameRule instance
     * @param frameRule  instance of a rule object
     */
    Json::Value ConstructFrameRuleObj(const FrameRule &frameRule);

    /**
     * @brief Capture controller
     * 
     */
    Capture::CptrThrdArgs* mCptrCntl;
};