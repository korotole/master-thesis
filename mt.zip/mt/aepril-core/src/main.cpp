/**
 * @author Bc. Oleksandr Korotetskyi (oleksandr.korotetskyi@porsche-engineering.cz)
 *
 * !  Important:
 * 1. Before compiling this application make sure you set "Compile PcapPlusPlus with PF_RING" to "y" in configure-linux.sh. Otherwise
 *    the application won't compile
 * 2. Before running the application make sure you load the PF_RING kernel module: sudo insmod <PF_RING_LOCATION>/kernel/pf_ring.ko
 *    Otherwise the application will exit with an error log that instructs you to load the kernel module
 * 3. This application (like all applications using PF_RING) should be run as 'sudo'
 */
#include "SystemLogic.h"

int main(int argc, char* argv[])
{
	SystemLogic logic = SystemLogic(argc, argv);

	auto result = logic.Initialize(argc, argv);
	if(result != 0)
	{
		LOG_DEBUG("Exiting with code: " + std::to_string(result));
		return result;
	}

	LOG_DEBUG("SystemLogic initialized.");
	result = logic.DoWork();
	LOG_DEBUG("Exiting with code: " + std::to_string(result));

	return result;
}