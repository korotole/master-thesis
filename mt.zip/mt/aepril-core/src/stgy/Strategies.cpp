#include "Strategies.h"

namespace stgy
{
    void ModifyStgy::Init(const FrameRule &rule)
    {
        if (rule.secret_key.size() != 0)
        {
            Aes128::aes128_init_cmac(&(mCtx), rule.secret_key.data());
        }
    }

    void ModifyStgy::Execute(pcpp::Packet *packet, size_t threadId, uint64_t pckt_idx) const
    {
        pcpp::UdpLayer *udpPayloadLayer = NULL;
        pcpp::TcpLayer *tcpPayloadLayer = NULL;        

        bool res = PreModificationChecks(packet, mRule, &udpPayloadLayer, &tcpPayloadLayer);


        if (res)
        {
            auto payload = udpPayloadLayer != NULL ? udpPayloadLayer->getNextLayer()->getData() : tcpPayloadLayer->getNextLayer()->getData();
            auto payloadLength = udpPayloadLayer != NULL ? udpPayloadLayer->getNextLayer()->getDataLen() : tcpPayloadLayer->getNextLayer()->getDataLen();

            //! PDU structure: [HEADER][SDU]
            //! SDU structure: [MAC][CRC][BZ][SIGNAL1][SIGNAL2]... (if all the fields are present)

            uint32_t pduPosition = 0;
            uint32_t pduLength = 0;

            bool pduFound = GetPduInfo(payload, payloadLength, mRule, &pduPosition, &pduLength);
            uint64_t bz = 0, crc = 0;

            if (pduFound) //! rule is matched, perform the actual signal modification
            {
                LOG_DEBUG("Thread " + std::to_string(threadId) + ": " + "packet " + std::to_string(pckt_idx) + " matched rule " + std::to_string(mRule.id) + ".");

                //* update selected signal with the new value
                WriteData(
                    payload + pduPosition + (mRule.signal_start_bit / 8),
                    mRule.signal_start_bit % 8,
                    mRule.signal_length,
                    mRule.new_value);

                LOG_DEBUG("Thread " + std::to_string(threadId) + ": " + "Strategy for rule " + std::to_string(mRule.id) + ": " + mRule.signal_name + " modified.");

                //* increment BZ if necessary and receive it's actual value
                if (mRule.bz_length != -1)
                {
                    // read actual bz
                    bz = ReadData(
                        payload + pduPosition + (mRule.bz_start_bit / 8),
                        mRule.bz_start_bit % 8,
                        mRule.bz_length);
                    LOG_DEBUG("Thread " + std::to_string(threadId) + ": " + "BZ read: " + std::to_string(bz) + ".");

#ifdef BZ_AUTO_INCREMENTATION
                    if (bz <= mBz.Read())
                    {
                        bz = (mBz.Read() + 1) % (int)std::pow(2, (int)mRule.bz_length); //* one byte assumed
                        mBz.Write(bz);

                        WriteData(
                            payload + pduPosition + (mRule.bz_start_bit / 8),
                            mRule.bz_start_bit % 8,
                            mRule.bz_length,
                            bz);
                    }
                    else
                    {
                        // update last used bz value
                        mBz.Write(bz);
                    }
#endif // BZ_AUTO_INCREMENTATION
                }

                //* recalculate the CRC of the PDU with the updated signal
                if (mRule.crc_length != -1)
                {
                    crc = CalculateCrc(
                        payload + pduPosition + (mRule.crc_start_bit / 8) + (mRule.crc_length / 8), // shift in selected PDU after the CRC field
                        (mRule.mac_length == -1)                                                    // length signals array is either:
                            ? (pduLength - mRule.crc_length / 8)                                    // PDU length - CRC length
                            : (pduLength - mRule.crc_length / 8 - mRule.mac_length),                // PDU length - CRC length - MAC length (if it is present)
                        mRule.polynomial,
                        bz);

                    WriteData(
                        payload + pduPosition + (mRule.crc_start_bit / 8),
                        mRule.crc_start_bit % 8,
                        mRule.crc_length,
                        crc);

                    LOG_DEBUG("Thread " + std::to_string(threadId) + ": " + "CRC calculated: " + std::to_string(crc) + ".");
                }

                //* recalculate the MAC of the resulting PDU
                if (mRule.mac_length != -1)
                {
                    uint8_t mac[Aes128::AES_BLOCK_SIZE];
                    Aes128::aes128_cmac(
                        &(mCtx),
                        payload + pduPosition + (mRule.mac_start_bit / 8),
                        mRule.mac_length,
                        mac);
                    WriteData(
                        payload + pduPosition + (mRule.mac_start_bit / 8),
                        mRule.mac_start_bit % 8,
                        mRule.mac_length,
                        GetBits(mac, Aes128::AES_BLOCK_SIZE, AES_CMAC_BIT_NUM_TRUNC, true));

                    LOG_DEBUG("Thread " + std::to_string(threadId) + ": " + "MAC calculated: " + std::to_string(GetBits(mac, Aes128::AES_BLOCK_SIZE, AES_CMAC_BIT_NUM_TRUNC, true)));
                }

                UpdateRuleUsage();

                //* recalculate FCS and other checksums
                (*packet).computeCalculateFields();
            }
        }
    }

    void FilterStgy::Execute(pcpp::Packet *packet, size_t threadId, uint64_t pckt_idx) const
    {
        pcpp::UdpLayer *udpPayloadLayer = NULL;
        pcpp::TcpLayer *tcpPayloadLayer = NULL;      
        bool res = PreModificationChecks(packet, mRule, &udpPayloadLayer, &tcpPayloadLayer);

        if (res)
        {
            if (mRule.pdu_id != -1)
            {
            auto payload = udpPayloadLayer != NULL ? udpPayloadLayer->getNextLayer()->getData() : tcpPayloadLayer->getNextLayer()->getData();
            auto payloadLength = udpPayloadLayer != NULL ? udpPayloadLayer->getNextLayer()->getDataLen() : tcpPayloadLayer->getNextLayer()->getDataLen();

                uint32_t pduPosition = -1;
                uint32_t pduLength = -1;

                bool pduFound = GetPduInfo(payload, payloadLength, mRule, &pduPosition, &pduLength);
                if (pduFound)
                {
                    LOG_DEBUG("Thread " + std::to_string(threadId) + ": " + "packet " + std::to_string(pckt_idx) + " matched rule " + std::to_string(mRule.id) + ".");
                    (*packet).getRawPacket()->clear();
                    UpdateRuleUsage();
                }
            }
            else
            {
                LOG_DEBUG("Thread " + std::to_string(threadId) + ": " + "packet " + std::to_string(pckt_idx) + " matched rule " + std::to_string(mRule.id) + ".");
                (*packet).getRawPacket()->clear();
                UpdateRuleUsage();
            }
        }
    }

} // namespace stgy
