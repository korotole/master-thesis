#pragma once

#include <PfRingDevice.h>
#include <PcapFileDevice.h>
#include <shared_mutex>
#include <cstdint>
#include <thread>
#include "FrameRule.h"
#include "StgyElems.h"

namespace stgy
{

    class IStrategy
    {
    public:
        /**
         * @brief Constructor for IStrategy that initializes the strategy module.
         */
        IStrategy(const FrameRule &rule)
            : mRule(rule), mUsgCntr(0), mStatus(rule.status)
        {
            if (rule.duration_type != "cyc" && rule.duration_type != "inf")
            {
                std::thread timer(&IStrategy::DeactivateOnTimeElapsed, this, utils::ConvertToDuration(rule.duration, rule.duration_type));
                timer.detach();
            }
        }

        virtual ~IStrategy() {}

        /**
         * @brief Executes strategy.
         *
         * @param packet A packet that needs to be processed
         */
        virtual void Execute(pcpp::Packet *packet, size_t threadId, uint64_t pckt_idx) const = 0;

        /**
         * @brief Checks if the strategy is active
         *
         * @return true
         * @return false
         */
        bool IsActive()
        {
            return mStatus.Read();
        }

        int64_t GetRuleId()
        {
            return mRule.id;
        }

    protected:
        FrameRule mRule;                                 // The actual rule strategy is operating with
        mutable utils::SharedResource<int32_t> mUsgCntr; // How many times the rule was actually used
        mutable utils::SharedResource<bool> mStatus;     // Whether the strategy is still active

        void UpdateRuleUsage() const
        {
            if (!mStatus.Read() || mRule.duration_type != "cyc")
            {
                // case when "inf / ms / s / m" or not rule is not active
                return;
            }

            mUsgCntr.Write(mUsgCntr.Read() + 1);

            if (mUsgCntr.Read() == mRule.duration)
            {
                mStatus.Write(false);
                LOG_DEBUG("Strategy for rule " + std::to_string(mRule.id) + "deactivated.")
            }
        }

    private:
        /**
         * @brief Deactivates a rule with specified id after specified duration
         *
         * @param duration
         */
        inline void DeactivateOnTimeElapsed(std::chrono::milliseconds duration)
        {
            std::this_thread::sleep_for(duration);
            mStatus.Write(false);
            LOG_DEBUG("Strategy for rule " + std::to_string(mRule.id) + "deactivated.")
        }
    };

} // stgy