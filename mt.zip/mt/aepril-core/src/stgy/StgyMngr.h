#pragma once

#include <memory>
#include "FrameRule.h"
#include "IStrategy.h"
#include "Strategies.h"

namespace stgy
{

    /**
     * @brief Strategy Manager class
     *
     * Determines the actual strategy and creates it
     */
    class StgyMngr
    {
    public:
        enum class StgyType
        {
            Modify,
            Filter
        };

        /*
         * Factory method for generating specified strategy
         */
        static std::unique_ptr<IStrategy> CreateStrategy(const FrameRule &rule)
        {
            const auto type = SelectStrategy(rule);
            if (type == StgyType::Modify)
            {
                return std::make_unique<ModifyStgy>(rule);
            }
            else // StgyType::Filter
            {
                return std::make_unique<FilterStgy>(rule);
            }
        }

    private:
        /*
         * Select the proper strategy according to the rule
         */
        static StgyType SelectStrategy(const FrameRule &rule)
        {
            if (!rule.mode) //* signal modification
            {
                return StgyType::Modify;
            }
            else //* traffic filtering
            {
                return StgyType::Filter;
            }
        }
    };

} // stgy
