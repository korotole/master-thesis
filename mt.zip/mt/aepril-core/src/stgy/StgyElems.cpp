#include "StgyElems.h"

namespace stgy
{
    bool PreModificationChecks(pcpp::Packet* packet, const FrameRule &rule, pcpp::UdpLayer **udpPayloadLayer, pcpp::TcpLayer **tcpPayloadLayer)
    {
        // check if source and destination addresses match
        // IPv6 check
        pcpp::IPv6Layer *ipv6Layer = (*packet).getLayerOfType<pcpp::IPv6Layer>();

        // check if source and destination ips match if they are set
        if ((ipv6Layer->getSrcIPv6Address().toString() != rule.src_ip && rule.src_ip != "") ||
            (ipv6Layer->getDstIPv6Address().toString() != rule.dest_ip && rule.dest_ip != ""))
        {
            LOG_DEBUG("Wrong IP.");
            LOG_DEBUG("{src} obtained:" + ipv6Layer->getSrcIPv6Address().toString() + ", desired: " + rule.src_ip);
            LOG_DEBUG("{dst} obtained:" + ipv6Layer->getDstIPv6Address().toString() + ", desired: " + rule.dest_ip);

            //* packet does not match the rule
            return false;
        }

        LOG_INFO("IP addesses matched.");
        // retrieve the protocol layer of frame
        *udpPayloadLayer = (*packet).getLayerOfType<pcpp::UdpLayer>();
        *tcpPayloadLayer = (*packet).getLayerOfType<pcpp::TcpLayer>();

        if (udpPayloadLayer == NULL && tcpPayloadLayer == NULL)
        {
            LOG_DEBUG("Wrong protocol.");

            //* protocols other than UDP and TCP not supported, skip the frame
            return false;
        }

        int32_t srcPort = 0, dstPort = 0;

        // Check if the packet is UDP or TCP and set appropriate variables
        if (udpPayloadLayer != NULL)
        {   
            srcPort = (*udpPayloadLayer)->getSrcPort();
            dstPort = (*udpPayloadLayer)->getDstPort();
        }
        else if (tcpPayloadLayer != NULL)
        {
            srcPort = (*tcpPayloadLayer)->getSrcPort();
            dstPort = (*tcpPayloadLayer)->getDstPort();
        }
        else
        {
            //* packet is not TCP or UDP, skip it
            return false;
        }

        // Check if source and destination ports match (if they are set)
        if (((int)rule.src_port != -1 && (int) srcPort != (int) rule.src_port) || ((int)rule.dest_port != -1 && (int)dstPort != (int)rule.dest_port))
        {   
            LOG_DEBUG("Wrong port.");
            LOG_DEBUG("{src} obtained:" + std::to_string(srcPort) + ", desired: " + std::to_string(rule.src_port));
            LOG_DEBUG("{dst} obtained:" + std::to_string(dstPort) + ", desired: " + std::to_string(rule.dest_port));
            //* rule not matched, skip packet
            return false;
        }
        
        return true;
    }

    uint64_t GetBits(const uint8_t *array, int len, uint8_t num, bool end)
    {
        // Ensure num is within the range of 0 to 64
        num = std::min(num, static_cast<uint8_t>(64));

        uint64_t result = 0;

        if (end)
        {
            // Extract from the most significant bits
            for (int i = len - 1, bits_collected = 0; i >= 0 && bits_collected < num; --i)
            {
                int bits_to_copy = std::min(num - bits_collected, 8);
                uint64_t byte = array[i];
                result = (result << bits_to_copy) | (byte >> (8 - bits_to_copy));
                bits_collected += bits_to_copy;
            }
        }
        else
        {
            // Extract from the least significant bits
            for (int i = 0, bits_collected = 0; i < len && bits_collected < num; ++i)
            {
                int bits_to_copy = std::min(num - bits_collected, 8);
                uint64_t byte = array[i];
                result |= (byte << bits_collected);
                bits_collected += bits_to_copy;
            }
        }

        return result;
    }

    uint8_t CalculateCrc(const uint8_t *input_bytes, size_t input_length, const std::vector<uint8_t> &scode, int bz)
    {
        uint8_t crc = 0xFF;
        constexpr uint8_t cb_crc_poly = 0x2f;

        // Execution
        for (size_t byte_index = 1; byte_index < input_length; ++byte_index)
        {
            crc ^= input_bytes[byte_index];
            for (int bit_index = 0; bit_index < 8; ++bit_index)
            {
                if (crc & 0x80)
                {
                    crc = (0xff & (crc << 1)) ^ cb_crc_poly;
                }
                else
                {
                    crc = (0xff & (crc << 1));
                }
            }
        }

        crc ^= scode[bz];

        for (int bit_index = 0; bit_index < 8; ++bit_index)
        {
            if (crc & 0x80)
            {
                crc = (0xff & (crc << 1)) ^ cb_crc_poly;
            }
            else
            {
                crc = (0xff & (crc << 1));
            }
        }

        crc ^= 0xff;

        return crc;
    }

    uint64_t ReadData(const uint8_t *payload, uint32_t start_bit, uint32_t length)
    {
        uint64_t value = 0;
        uint32_t byte_index = start_bit / 8;
        uint32_t bit_index = start_bit % 8;
        uint32_t bits_read = 0;

        while (bits_read < length)
        {
            uint8_t bits_to_read = std::min(8 - bit_index, length - bits_read);
            uint8_t extracted_bits = (payload[byte_index] >> bit_index) & ((1 << bits_to_read) - 1);

            value |= extracted_bits << bits_read;

            bits_read += bits_to_read;
            bit_index = 0;
            ++byte_index;
        }

        return value;
    }

    /*
     * Function shall substitute the actual signal value with the new one.
     */
    void WriteData(uint8_t *data, uint32_t start_bit, uint32_t length, uint64_t substitute)
    {
        uint32_t byte_pos = start_bit / 8;
        uint8_t bit_pos = start_bit % 8;

        uint64_t mask = (1ull << length) - 1;
        substitute &= mask;
        substitute <<= bit_pos;

        uint64_t current_val = 0;
        uint32_t i;
        for (i = 0; i < (length + bit_pos + 7) / 8; i++)
        {
            current_val |= (uint64_t)data[byte_pos + i] << (i * 8);
        }

        mask <<= bit_pos;
        current_val &= ~mask;
        current_val |= substitute;

        for (i = 0; i < (length + bit_pos + 7) / 8; i++)
        {
            data[byte_pos + i] = (current_val >> (i * 8)) & 0xff;
        }
    }

#ifdef PDU_LONG_HEADERS
    bool ProcessLongHeaderPdus(uint8_t *packet_payload, size_t payload_size, const FrameRule &rule, uint32_t *position, uint32_t *length)
    {
        size_t pos = 0;
        while (pos < payload_size)
        {
            //! handling the PDU HEADER
            uint32_t pdu_id = (packet_payload[pos + 0] << 24) | (packet_payload[pos + 1] << 16) | (packet_payload[pos + 2] << 8) | packet_payload[pos + 3];
            uint32_t pdu_dlc = (packet_payload[pos + 4] << 24) | (packet_payload[pos + 5] << 16) | (packet_payload[pos + 6] << 8) | packet_payload[pos + 7];
            pos += 8;

            if (pdu_id == rule.pdu_id)
            {
                //! PDU-SDU data
                *position = pos;
                *length = pdu_dlc;
                return true;
            }
            pos += pdu_dlc;
        }
        return false;
    }
#endif // PDU_LONG_HEADERS

#ifdef PDU_SHORT_HEADERS
    bool ProcessShortHeaderPdus(uint8_t *packet_payload, size_t payload_size, const FrameRule &rule, uint32_t *position, uint32_t *length)
    {
        size_t pos = 0;
        while (pos < payload_size)
        {
            //! handling the PDU HEADER
            uint32_t pdu_id = (packet_payload[pos + 0] << 16) | (packet_payload[pos + 1] << 8) | packet_payload[pos + 2];
            uint32_t pdu_dlc = packet_payload[pos + 3];
            pos += 4;

            if (pdu_id == rule.pdu_id)
            {
                //! PDU-SDU data
                *position = pos;
                *length = pdu_dlc;
                return true;
            }
            pos += pdu_dlc;
        }
        return false;
    }
#endif // PDU_SHORT_HEADERS

    /// @brief Get info about Pdu containing the desired signal
    bool GetPduInfo(uint8_t *packet_payload, size_t payload_size, const FrameRule &rule, uint32_t *position, uint32_t *length)
    {

#ifdef PDU_LONG_HEADERS
        return ProcessLongHeaderPdus(packet_payload, payload_size, rule, position, length);
#endif // PDU_LONG_HEADERS

#ifdef PDU_SHORT_HEADERS
        return ProcessShortHeaderPdus(packet_payload, payload_size, rule, position, length);
#endif // PDU_SHORT_HEADERS
    }

    // Performs a substitution non-linear substitution table used to perform one-to-one byte substitutions
    uint8_t Aes128::sbox_lookup(uint8_t index, bool invert)
    {
        static constexpr uint8_t sbox[256] = {
            0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
            0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
            0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
            0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
            0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
            0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
            0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
            0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
            0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
            0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
            0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
            0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
            0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
            0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
            0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
            0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16};

        static constexpr uint8_t rsbox[256] = {
            0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
            0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,
            0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
            0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,
            0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,
            0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
            0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,
            0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,
            0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
            0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,
            0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,
            0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
            0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,
            0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,
            0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
            0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d};

        return invert ? rsbox[index] : sbox[index];
    }

    // Precalculated lookup table instead of recursive polynomial multiplication
    uint8_t Aes128::gfmul(uint8_t x, uint8_t y)
    {
        static constexpr uint8_t mask[8] = {0x00, 0x1b, 0x36, 0x2d, 0x6c, 0x77, 0x5a, 0x41};
        uint16_t r = (x * (y & 0x1)) ^ (x * (y & 0x2)) ^ (x * (y & 0x4)) ^ (x * (y & 0x8));
        return (uint8_t)(r ^ mask[r >> 8]);
    }

    void Aes128::xor128(uint8_t *a, const uint8_t *b)
    {
        for (size_t i = 0; i < Aes128::AES_BLOCK_SIZE; i++)
        {
            a[i] ^= b[i];
        }
    }

    // Generate a key schedule using the cipher key
    void Aes128::aes_key_expansion(uint8_t *round_key, const uint8_t *key)
    {
        static constexpr uint8_t round_constants[11] = {0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36};

        // First round key
        memcpy(round_key, key, Aes128::AES_KEY_LEN);

        uint8_t word[4];
        for (size_t i = Aes128::AES_WORD_COUNT; i < (4 * (Aes128::AES_ROUNDS + 1)); i++)
        {
            for (size_t j = 0; j < 4; j++)
            {
                word[j] = round_key[4 * (i - 1) + j];
            }

            // Rotate and substitute
            if (!(i % Aes128::AES_WORD_COUNT))
            {
                const uint8_t _word = word[0];
                word[0] = word[1];
                word[1] = word[2];
                word[2] = word[3];
                word[3] = _word;

                for (size_t j = 0; j < 4; j++)
                {
                    word[j] = sbox_lookup(word[j], false);
                }

                word[0] ^= round_constants[i / 4];
            }

            for (size_t j = 0; j < 4; j++)
            {
                round_key[(4 * i) + j] = round_key[(4 * (i - Aes128::AES_WORD_COUNT)) + j] ^ word[j];
            }
        }
    }

    // AES-CMAC subkey generation algorithm
    void Aes128::aes_generate_subkey(uint8_t *key)
    {
        uint8_t msb = key[0] & 0x80;
        for (size_t i = 0; i < 15; i++)
        {
            key[i] = (uint8_t)(key[i] << 1U) | (key[i + 1] >> 7U);
        }

        key[15] = (uint8_t)(key[15] << 1U);
        if (msb)
        {
            key[15] ^= 0x87; // const_Rb
        }
    }

    // XOR a Round Key into the state
    void Aes128::aes_add_round_key(state_t *ctx, uint8_t round, const uint8_t *round_key)
    {
        for (size_t i = 0; i < 4; i++)
        {
            for (size_t j = 0; j < 4; j++)
            {
                ctx->s[i][j] ^= round_key[(AES_BLOCK_SIZE * round) + (4 * i) + j];
            }
        }
    }

    // Substitute bytes in the state using sbox / rsbox
    void Aes128::aes_substitute_bytes(state_t *ctx, bool invert)
    {
        for (size_t i = 0; i < 4; i++)
        {
            for (size_t j = 0; j < 4; j++)
            {
                ctx->s[j][i] = sbox_lookup(ctx->s[j][i], invert);
            }
        }
    }

    // Cyclically shift the last three rows of the State with different offsets
    void Aes128::aes_shift_rows(state_t *ctx, bool invert)
    {
        static const uint8_t r1map_inverted[] = {3, 2, 1, 0};
        static const uint8_t r1map_normal[] = {0, 1, 2, 3};
        static const uint8_t r3map_inverted[] = {0, 3, 2, 1};
        static const uint8_t r3map_normal[] = {0, 1, 2, 3};

        const uint8_t *r1map = invert ? r1map_inverted : r1map_normal;
        const uint8_t *r3map = invert ? r3map_inverted : r3map_normal;

        // Cycle the first row 1 column to the left or right
        uint8_t s = ctx->s[r1map[0]][1];
        ctx->s[r1map[0]][1] = ctx->s[r1map[1]][1];
        ctx->s[r1map[1]][1] = ctx->s[r1map[2]][1];
        ctx->s[r1map[2]][1] = ctx->s[r1map[3]][1];
        ctx->s[r1map[3]][1] = s;

        // Cycle the second row 2 columns
        s = ctx->s[0][2];
        ctx->s[0][2] = ctx->s[2][2];
        ctx->s[2][2] = s;

        s = ctx->s[1][2];
        ctx->s[1][2] = ctx->s[3][2];
        ctx->s[3][2] = s;

        // Cycle the third row 3 columns to the left or right
        s = ctx->s[0][3];
        ctx->s[r3map[0]][3] = ctx->s[r3map[3]][3];
        ctx->s[r3map[3]][3] = ctx->s[r3map[2]][3];
        ctx->s[r3map[2]][3] = ctx->s[r3map[1]][3];
        ctx->s[r3map[1]][3] = s;
    }

    // Mix the contents of the state's columns to produce new columns
    // s`(x) = a(x) ⊗ s(x)
    void Aes128::aes_mix_columns(state_t *ctx, bool invert)
    {
        if (invert)
        {
            for (size_t i = 0; i < 4; i++)
            {
                uint8_t s[4] = {ctx->s[i][0], ctx->s[i][1], ctx->s[i][2], ctx->s[i][3]};

                ctx->s[i][0] = gfmul(s[0], 0xe) ^ gfmul(s[1], 0xb) ^ gfmul(s[2], 0xd) ^ gfmul(s[3], 0x9);
                ctx->s[i][1] = gfmul(s[0], 0x9) ^ gfmul(s[1], 0xe) ^ gfmul(s[2], 0xb) ^ gfmul(s[3], 0xd);
                ctx->s[i][2] = gfmul(s[0], 0xd) ^ gfmul(s[1], 0x9) ^ gfmul(s[2], 0xe) ^ gfmul(s[3], 0xb);
                ctx->s[i][3] = gfmul(s[0], 0xb) ^ gfmul(s[1], 0xd) ^ gfmul(s[2], 0x9) ^ gfmul(s[3], 0xe);
            }
        }
        else
        {
            for (size_t i = 0; i < 4; i++)
            {
                uint8_t s = ctx->s[i][0] ^ ctx->s[i][1] ^ ctx->s[i][2] ^ ctx->s[i][3];
                uint8_t c0 = ctx->s[i][0];

                for (size_t j = 0; j < 4; j++)
                {
                    // XOR s[i][3] with the previous s[i][0]
                    uint8_t c = ctx->s[i][j] ^ ((j == 3) ? c0 : ctx->s[i][j + 1]);
                    c = (uint8_t)(c << 1U) ^ (((c >> 7) & 1) * 0x1b);
                    ctx->s[i][j] ^= c ^ s;
                }
            }
        }
    }

    // Main cipher function
    void Aes128::aes_xcrypt(state_t *state, const uint8_t *round_key)
    {
        aes_add_round_key(state, 0, round_key);
        for (size_t i = 1;; i++)
        {
            aes_substitute_bytes(state, false);
            aes_shift_rows(state, false);
            if (i == AES_ROUNDS)
            {
                break;
            }
            aes_mix_columns(state, false);
            aes_add_round_key(state, i, round_key);
        }
        aes_add_round_key(state, AES_ROUNDS, round_key);
    }

    void Aes128::aes128_cmac(const aes128_t *ctx, const uint8_t *msg, size_t length, uint8_t *mac)
    {
        // Subkey generation (pg 5 RFC 4493)
        uint8_t L[AES_BLOCK_SIZE] = {0}; // Output of AES(0)
        aes_xcrypt((state_t *)L, ctx->round_key);
        aes_generate_subkey(L);

        // MAC generation (pg 7 RFC 4493)
        uint8_t block[AES_BLOCK_SIZE] = {0};
        for (; length; length -= AES_BLOCK_SIZE)
        {
            if (length < AES_BLOCK_SIZE)
            {
                aes_generate_subkey(L);
                L[length] ^= AES_KEY_BITS;
            }
            if (length <= AES_BLOCK_SIZE)
            {
                for (size_t i = 0; i < length; i++)
                {
                    L[i] ^= msg[i];
                }
                length = AES_BLOCK_SIZE;
                msg = L;
            }

            xor128(block, msg);
            aes_xcrypt((state_t *)block, ctx->round_key);
            msg += AES_BLOCK_SIZE;
        }
        memcpy(mac, block, AES_BLOCK_SIZE);
    }

    void Aes128::aes128_init_cmac(aes128_t *ctx, const uint8_t *key)
    {
        memset(ctx, 0, sizeof(*ctx));
        aes_key_expansion(ctx->round_key, key);
    }

    // static void InitializeFcsTable(uint32_t *table)
    // {
    //     uint32_t polynomial = FCS_POLYNOMIAL;
    //     for (uint32_t i = 0; i < 256; ++i)
    //     {
    //         uint32_t c = i;
    //         for (size_t j = 0; j < 8; ++j)
    //         {
    //             if (c & 1)
    //             {
    //                 c = polynomial ^ (c >> 1);
    //             }
    //             else
    //             {
    //                 c >>= 1;
    //             }
    //         }
    //         table[i] = c;
    //     }
    // }

    // static uint32_t CalculateFcs(const uint8_t *data, size_t length, uint32_t *table)
    // {
    //     uint32_t crc = 0xFFFFFFFF;
    //     for (size_t i = 0; i < length; ++i)
    //     {
    //         uint8_t byte = data[i];
    //         uint8_t pos = (byte ^ crc) & 0xFF;
    //         crc = (crc >> 8) ^ table[pos];
    //     }
    //     return ~crc;
    // }
} // stgy