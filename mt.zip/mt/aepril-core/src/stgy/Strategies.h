#pragma once

#include <cmath>
#include "IStrategy.h"
#include "Utilities.h"

namespace stgy
{
    /**
     * @brief Signal modification
     *
     */
    class ModifyStgy : public IStrategy
    {
    public:
        ModifyStgy(const FrameRule &rule) : IStrategy(rule), mBz(0)
        {
            Init(rule);
        }

        void Execute(pcpp::Packet *packet, size_t threadId, uint64_t pckt_idx) const override;

    private:
        // last used BZ counter
        mutable utils::SharedResource<uint8_t> mBz;
        // AES128 context
        Aes128::aes128_t mCtx;

        /**
         * @brief Initializes the strategy module.
         *
         * @param rule A FrameRule container specifying the actual configuration
         */
        void Init(const FrameRule &rule);
    };

    /**
     * @brief Filtering packets
     *
     */
    class FilterStgy : public IStrategy
    {
    public:
        FilterStgy(const FrameRule &rule) : IStrategy(rule) {}
        void Execute(pcpp::Packet *packet, size_t threadId, uint64_t pckt_idx) const override;
    };
} // namespace stgy
