#pragma once

#include <cstdlib>
#include <list>
#include <map>
#include <sstream>
#include <string>
#include <vector>
#include <unistd.h>
#include <IPLayer.h>
#include <IPv4Layer.h>
#include <IPv6Layer.h>
#include <PcapFileDevice.h>
#include <PcapPlusPlusVersion.h>
#include <PfRingDeviceList.h>
#include <ProtocolType.h>
#include <TcpLayer.h>
#include <UdpLayer.h>
#include <PacketUtils.h>
#include <SystemUtils.h>
#include <TablePrinter.h>
#include <EventLogger.h>
#include <mutex>
#include "conf.h"
#include "FrameRule.h"

namespace stgy
{
	/**
	 * @brief
	 *
	 * @param packet
	 * @param rule
	 * @param payloadLayer
	 * @return true
	 * @return false
	 */
	bool PreModificationChecks(pcpp::Packet *packet, const FrameRule &rule, pcpp::UdpLayer **udpPayloadLayer, pcpp::TcpLayer **tcpPayloadLayer);

#ifdef PDU_LONG_HEADERS
	/**
	 * @brief Processes Protocol Data Units (PDUs) with long headers from a packet payload.
	 *
	 * @param packet_payload Pointer to the packet payload data.
	 * @param payload_size The size of the packet payload.
	 * @param rule The rule set for matching and processing the PDUs.
	 * @param position Pointer to store the position of the matched PDU.
	 * @param length Pointer to store the length of the matched PDU.
	 */
	bool ProcessLongHeaderPdus(uint8_t *packet_payload, size_t payload_size, const FrameRule &rule, uint32_t *position, uint32_t *length);
#endif // PDU_LONG_HEADERS

#ifdef PDU_SHORT_HEADERS
	/**
	 * @brief Processes Protocol Data Units (PDUs) with short headers from a packet payload.
	 *
	 * @param packet_payload Pointer to the packet payload data.
	 * @param payload_size The size of the packet payload.
	 * @param rule The rule set for matching and processing the PDUs.
	 * @param position Pointer to store the position of the matched PDU.
	 * @param length Pointer to store the length of the matched PDU.
	 */
	bool ProcessShortHeaderPdus(uint8_t *packet_payload, size_t payload_size, const FrameRule &rule, uint32_t *position, uint32_t *length);
#endif // PDU_SHORT_HEADERS

	/**
	 * @brief Retrieves the Protocol Data Unit (PDU) information from a packet payload.
	 *
	 * @param packet_payload Pointer to the packet payload data.
	 * @param payload_size The size of the packet payload.
	 * @param rule The rule set to identify the relevant PDU.
	 * @param position Pointer to store the position of the identified PDU.
	 * @param length Pointer to store the length of the identified PDU.
	 */
	bool GetPduInfo(uint8_t *packet_payload, size_t payload_size, const FrameRule &rule, uint32_t *position, uint32_t *length);

	/**
	 * @brief Substitutes a portion of data starting at a specific bit with a given value.
	 *
	 * @param data Pointer to the data array where substitution will occur.
	 * @param start_bit The starting bit position in the data array for substitution.
	 * @param length The number of bits to be substituted.
	 * @param substitute The value to be substituted into the data array.
	 */
	void WriteData(uint8_t *data, uint32_t start_bit, uint32_t length, uint64_t substitute);

	/**
	 * @brief
	 *
	 * @param data
	 * @param pduPosition
	 * @param pduLength
	 * @param rule
	 * @return uint8_t
	 */
	uint64_t ReadData(const uint8_t *payload, uint32_t start_bit, uint32_t length);
	/**
	 * @brief Calculates the Cyclic Redundancy Check (CRC) for a given Protocol Data Unit (PDU) in a packet payload.
	 *
	 * This function computes the CRC by iterating over each byte of the input array (excludes very CRC and MAC info),
	 * and applies a specified polynomial to generate the CRC. The function then incorporates a supplementary code
	 * from a vector of bytes at a specific index and concludes the CRC computation.
	 *
	 * @param input_bytes Pointer to an array of uint8_t representing the PDU.
	 * @param input_length Length of the input_bytes array.
	 * @param scode Vector of uint8_t representing supplementary codes. A specific element is selected for the CRC computation.
	 * @param bz Index to select the appropriate element from the scode vector for the CRC computation.
	 * @return uint8_t The calculated CRC value as an 8-bit unsigned integer.
	 */
	uint8_t CalculateCrc(const uint8_t *input_bytes, size_t input_length, const std::vector<uint8_t> &scode, int bz);

	/**
	 * @brief Extracts a specified number of bits from a 128-bit number represented by a len-element array of uint8_t.
	 *
	 * The function extracts either the most significant bits or the least significant bits from the array,
	 * depending on the value of the 'end' parameter. It accumulates the extracted bits into a uint64_t value
	 * and returns this value. The function handles both forward and reverse extraction based on the 'end' flag.
	 *
	 * @param array Pointer to a 16-element array of uint8_t, representing a 128-bit number.
	 * @param len The total number of elements in the array (should be 16 for a 128-bit number).
	 * @param num The number of bits to extract from the array. The number of bits is capped at 64.
	 * @param end A boolean flag indicating the end from which to start extraction:
	 *            'true' for the MOST significant bits, 'false' for the LEAST significant bits.
	 * @return uint64_t The extracted bits accumulated into a 64-bit unsigned integer.
	 */
	uint64_t GetBits(const uint8_t *array, int len, uint8_t num, bool end);

	class Aes128
	{
	public:
		// Enumerations defining AES constants
		enum
		{
			AES_WORD_COUNT = 4,				// Number of words in the AES key
			AES_ROUNDS = 10,				// Number of AES encryption rounds
			AES_BLOCK_SIZE = 16,			// Block size in bytes for AES
			AES_KEY_LEN = 16,				// Key length in bytes for AES
			CMAC_KEY_LEN = 16,				// Key length for CMAC
			AES_KEY_BITS = 8 * AES_KEY_LEN, // Total number of bits in the AES key
		};

		// Union representing the state of AES encryption/decryption
		typedef union state_t
		{
			uint8_t s[4][4]; // State array for AES processing
		} state_t;

		// Struct representing the context of AES128 operations
		typedef struct
		{
			uint8_t round_key[AES_BLOCK_SIZE * (AES_ROUNDS + 1)]; // Expanded round keys for AES
		} aes128_t;

		// Public Interface for AES128 operations
		static void aes128_init_cmac(aes128_t *ctx, const uint8_t *key);							   // Initializes AES128 CMAC context
		static void aes128_cmac(const aes128_t *ctx, const uint8_t *msg, size_t length, uint8_t *mac); // Computes AES128 CMAC

	private:
		// Internal utility functions for AES128
		static uint8_t gfmul(uint8_t x, uint8_t y);											  // Multiplies two elements in GF(2^8)
		static uint8_t sbox_lookup(uint8_t index, bool invert);								  // Looks up in the S-Box or inverse S-Box
		static void xor128(uint8_t *a, const uint8_t *b);									  // Performs XOR operation on 128-bit blocks
		static void aes_key_expansion(uint8_t *round_key, const uint8_t *key);				  // Expands AES key for round operations
		static void aes_generate_subkey(uint8_t *key);										  // Generates subkeys for CMAC operation
		static void aes_add_round_key(state_t *ctx, uint8_t round, const uint8_t *round_key); // Adds round key to state
		static void aes_substitute_bytes(state_t *ctx, bool invert);						  // Substitutes bytes in the state using S-Box
		static void aes_shift_rows(state_t *ctx, bool invert);								  // Shifts rows in the state matrix
		static void aes_mix_columns(state_t *ctx, bool invert);								  // Mixes columns in the state matrix
		static void aes_xcrypt(state_t *state, const uint8_t *round_key);					  // Main AES encrypt/decrypt function
	};

	/**
	 * @brief Initializes the Frame Check Sequence (FCS) table used for CRC calculations.
	 *
	 * @param table Pointer to the table array to be initialized for FCS.
	 */
	// void InitializeFcsTable(uint32_t *table);

	/**
	 * @brief Calculates the Frame Check Sequence (FCS) using the CRC-32 algorithm.
	 *
	 * @param data Pointer to the data array for which the FCS is to be calculated.
	 * @param length The length of the data array.
	 * @param table The pre-generated Fcs table for fast frame CRC computation.
	 * @return The calculated FCS value.
	 */
	// uint32_t CalculateFcs(const uint8_t *data, size_t length, uint32_t *table);

} // stgy