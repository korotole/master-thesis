#pragma once

#include <iostream>
#include <fstream>
#include <chrono>
#include <ctime>
#include <cstring>
#include <shared_mutex>
#include <mutex>

#include "conf.h"

enum class LogLevel {
    Debug,
    Info,
    Warning,
    Error
};

class Logger {
  private:
    std::shared_mutex logMutex;          // a mutex for managing concurrency

    Logger(){}; 
    Logger(const Logger &old) = delete; // disallow copy constructor

    const Logger &operator=(const Logger &old) = delete; // disallow assignment operator

  public:
    static Logger &Instance()
    {
        static std::unique_ptr<Logger> instance( new Logger );
        return *instance; // always returns the same instance
    }

    template<typename M>
    void log(LogLevel level, const M& m, const char* file, const int line) {
        auto now = std::chrono::system_clock::now();
        std::time_t time = std::chrono::system_clock::to_time_t(now);
        char time_str[100];
        std::strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", std::localtime(&time));

        std::string loglevel_str;
        switch (level) {
            case LogLevel::Debug:
                loglevel_str = "D";
                break;
            case LogLevel::Info:
                loglevel_str = "I";
                break;
            case LogLevel::Warning:
                loglevel_str = "W";
                break;
            case LogLevel::Error:
                loglevel_str = "E";
                break;
        }

        std::string output_str = "[" + loglevel_str + "][" + std::string(time_str) + "][" + std::string(file) + ":" + std::to_string(line) + "] " + std::string(m);

        {
            std::scoped_lock lock(logMutex);

#ifdef CONSOLE_LOGGING       
            std::cout << get_console_color(level) << output_str << "\033[0m" << std::endl;
#endif //CONSOLE_LOGGING

#ifdef FILE_LOGGING
            std::ofstream logfile("./log.txt", std::ios_base::app);
            logfile << output_str << std::endl;
#endif //FILE_LOGGING
        }

    }

#ifdef CONSOLE_LOGGING
  private:
    static constexpr const char* get_console_color(LogLevel level) {
        switch (level) {
            case LogLevel::Debug:
                return "\033[36m"; // cyan
            case LogLevel::Info:
                return "\033[32m"; // green
            case LogLevel::Warning:
                return "\033[33m"; // yellow
            case LogLevel::Error:
                return "\033[31m"; // red
        }
        return "\0";
    }
#endif //CONSOLE_LOGGING
};


// macro to get the filename without the full path
#define __FILENAME__ (strrchr(__FILE__, '/') ? strrchr(__FILE__, '/') + 1 : __FILE__)

// turn logs on / off depending on the configuration
#ifdef DEBUG_LOGS_DISABLED
    #define LOG_DEBUG(msg) ;
#else
    #define LOG_DEBUG(msg) Logger::Instance().log(LogLevel::Debug, msg, __FILENAME__, __LINE__);
#endif //DEBUG_LOGS_DISABLED

#ifdef INFO_LOGS_DISABLED
    #define LOG_INFO(msg) ;
#else
    #define LOG_INFO(msg) Logger::Instance().log(LogLevel::Info, msg, __FILENAME__, __LINE__);
#endif //INFO_LOGS_DISABLED

#ifdef WARNING_LOGS_DISABLED
    #define LOG_WARNING(msg) ;
#else
    #define LOG_WARNING(msg) Logger::Instance().log(LogLevel::Warning, msg, __FILENAME__, __LINE__);
#endif //WARNING_LOGS_DISABLED

#ifdef ERROR_LOGS_DISABLED
    #define LOG_ERROR(msg) ;
#else
    #define LOG_ERROR(msg) Logger::Instance().log(LogLevel::Error, msg, __FILENAME__, __LINE__);
#endif //ERROR_LOGS_DISABLED
