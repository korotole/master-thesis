#include "Utilities.h"

namespace utils
{
    template <typename T>
    SharedResource<T>::SharedResource(T initialValue) : resource(initialValue) {}

    template <typename T>
    void SharedResource<T>::Write(const T &newValue)
    {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        resource = newValue;
    }

    template <typename T>
    T SharedResource<T>::Read() const
    {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        return resource;
    }

    std::string serializeVector(const std::vector<uint8_t> &vec)
    {
        std::ostringstream oss;
        for (size_t i = 0; i < vec.size(); ++i)
        {
            if (i != 0)
            {
                oss << ",";
            }
            oss << static_cast<int>(vec[i]);
        }
        return oss.str();
    }

    std::vector<uint8_t> deserializeVector(const std::string &str)
    {
        std::vector<uint8_t> vec;
        std::istringstream iss(str);
        std::string token;
        while (std::getline(iss, token, ','))
        {
            vec.push_back(static_cast<uint8_t>(std::stoi(token)));
        }
        return vec;
    }

    std::chrono::milliseconds ConvertToDuration(long long value, const std::string &unit)
    {
        if (unit == "ms")
        {
            return std::chrono::milliseconds(value + RULE_DEACTIVATION_EXTRA);
        }
        else if (unit == "s")
        {
            return std::chrono::milliseconds(value * 1000 + RULE_DEACTIVATION_EXTRA);
        }
        else if (unit == "m")
        {
            return std::chrono::milliseconds(value * 1000 * 60 + RULE_DEACTIVATION_EXTRA);
        }
        else
        {
            throw std::invalid_argument("Unsupported time unit");
        }
    }

    // Explicit template instantiation
    template class SharedResource<bool>;
    template class SharedResource<uint8_t>;
    template class SharedResource<int32_t>;
#ifdef PCKT_COUNT
    template class SharedResource<uint64_t>;
#endif // PCKT_COUNT
}
