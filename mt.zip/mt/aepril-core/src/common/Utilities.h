#pragma once

#include <string>
#include <vector>
#include <variant>
#include <algorithm>
#include <chrono>
#include <shared_mutex>
#include <mutex>
#include <sstream>
#include <string>
#include <stdexcept>
#include <cstdint>
#include "conf.h"

namespace utils
{
    template <typename T>
    class SharedResource
    {
    public:
        SharedResource(T initialValue = T());

        void Write(const T &newValue);
        T Read() const;

    private:
        T resource;
        mutable std::shared_mutex mutex_;
    };

    std::string serializeVector(const std::vector<uint8_t> &vec);
    std::vector<uint8_t> deserializeVector(const std::string &str);
    std::chrono::milliseconds ConvertToDuration(long long value, const std::string &unit);
} // namespace utils
