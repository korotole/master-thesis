#pragma once

#include <unordered_map>
#include <string>
#include <type_traits>
#include <mutex>

namespace err
{
#define OK 0

    enum RpcError
    {
        E_UPDATE_NO_ID_FOUND = -99,
        E_GET_NO_ID_FOUND,
        E_DELETE_NO_ID_FOUND,
        E_SET_NO_ID_FOUND,
        E_GET_DATABASE_EMPTY,
        E_DELETE_DATABASE_EMPTY,
        E_START_NO_ACTIVE_RULES,
        E_STOP_NO_ACTIVE_RULES
    };

    enum DbError
    {
        E_TEST = -199
    };

    enum LogicError
    {
        E_NO_PFRING_DEV_MASTER = -299,
        E_NO_FILE_READER_TYPE_MASTER,
        E_NO_PFRING_DEV_SLAVE,
        E_NO_FILE_READER_TYPE_SLAVE,
        E_NUM_OF_CAPTURE_THREADS,

        E_NO_MASTER,
        E_INVALID_USAGE_MASTER,
        E_NO_SLAVE,
        E_INVALID_USAGE_SLAVE,

        E_SAME_IFACE,
        E_SAME_FILE,

        E_OPENING_OF_RX_CHANNELS_FAILED_MASTER,

        E_OPENING_OF_MASTER_IFACE,
        E_OPENING_OF_SLAVE_IFACE,

        E_OPENING_OF_MASTER_FILE,
        E_OPENING_OF_SLAVE_FILE,

        E_CAPTURING_MASTER,
        E_CAPTURING_SLAVE,

        E_HTTP_SERVER,

        E_UNKOWN
    };

    template <typename T>
    class Error
    {
        static_assert(std::is_enum<T>::value, "Error requires enum type");

    public:
        // Delete copy constructor and assignment operator
        Error(const Error &) = delete;
        Error &operator=(const Error &) = delete;

        static Error &Instance()
        {
            static Error instance;
            return instance;
        }

        std::string ToString(T code)
        {
            std::lock_guard<std::mutex> lock(mutex_);
            auto it = errorMessages.find(static_cast<int>(code));
            if (it != errorMessages.end())
            {
                return it->second;
            }
            else
            {
                return "Unknown error";
            }
        }

    private:
        std::unordered_map<int, std::string> errorMessages;
        std::mutex mutex_;

        Error()
        {
            InitializeErrorMessages();
        }

        void InitializeErrorMessages()
        {
            if constexpr (std::is_same<T, err::RpcError>::value)
            {
                errorMessages[err::E_UPDATE_NO_ID_FOUND] = "Update failed: No ID found";
                errorMessages[err::E_GET_NO_ID_FOUND] = "Get failed: No ID found";
                errorMessages[err::E_DELETE_NO_ID_FOUND] = "Delete failed: No ID found";
                errorMessages[err::E_SET_NO_ID_FOUND] = "Set failed: No ID found";
                errorMessages[err::E_GET_DATABASE_EMPTY] = "Get failed: Database is empty";
                errorMessages[err::E_DELETE_DATABASE_EMPTY] = "Delete failed: Database is empty";
                errorMessages[err::E_START_NO_ACTIVE_RULES] = "Database contains no active rules, START is not possible.";
                errorMessages[err::E_STOP_NO_ACTIVE_RULES] = "Traffic interference is not in progress.";
            }
            else if constexpr (std::is_same<T, err::DbError>::value)
            {
                errorMessages[err::E_TEST] = "Database test error";
            }
            else if constexpr (std::is_same<T, err::LogicError>::value)
            {
                errorMessages[err::E_NO_PFRING_DEV_MASTER] = "Could not find PF_RING device for master";
                errorMessages[err::E_NO_FILE_READER_TYPE_MASTER] = "Could not determine file reader type for master";
                errorMessages[err::E_NO_PFRING_DEV_SLAVE] = "Could not find PF_RING device for slave";
                errorMessages[err::E_NO_FILE_READER_TYPE_SLAVE] = "Could not determine file reader type for slave";
                errorMessages[err::E_NUM_OF_CAPTURE_THREADS] = "Number of capture threads must be in the range of 1 to";

                errorMessages[err::E_NO_MASTER] = "Neither master interface nor master file were provided";
                errorMessages[err::E_INVALID_USAGE_MASTER] = "Please provide a master file or a master interface, not both at the same time";
                errorMessages[err::E_NO_SLAVE] = "Neither slave interface nor slave file were provided";
                errorMessages[err::E_INVALID_USAGE_SLAVE] = "Please provide a slave file or a slave interface, not both at the same time";

                errorMessages[err::E_SAME_IFACE] = "Master and slave interfaces are the same";
                errorMessages[err::E_SAME_FILE] = "Master and slave files are the same";

                errorMessages[err::E_OPENING_OF_RX_CHANNELS_FAILED_MASTER] = "Could not open the following number of RX channels on the master interface";

                errorMessages[err::E_OPENING_OF_MASTER_IFACE] = "Could not open master interface";
                errorMessages[err::E_OPENING_OF_SLAVE_IFACE] = "Could not open slave interface";

                errorMessages[err::E_OPENING_OF_MASTER_FILE] = "Could not open master file";
                errorMessages[err::E_OPENING_OF_SLAVE_FILE] = "Could not open slave file";

                errorMessages[err::E_CAPTURING_MASTER] = "Could not start capturing on the master interface, core mask 0x";
                errorMessages[err::E_CAPTURING_SLAVE] = "Could not start capturing on the slave interface, core mask 0x";

                errorMessages[err::E_HTTP_SERVER] = "Error starting HTTP server";
            }
        }
    };

} // namespace err