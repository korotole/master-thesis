# Requirements
Install the following packages:
```linux-headers-amd64 build-essential clang bison flex ethtool cmake libjsoncpp-dev libargtable2-dev catch libjsonrpccpp-dev libjsonrpccpp-tools libpcap-dev```

# Build Instructions
To download and compile dependencies (needed only on the first run):
```./setup.sh```
To build the project:
```bash ./build.sh```

# How to generate JSON-RPC header
(In repository root:)
```libjson-rpc-cpp/build/bin/jsonrpcstub -v src/rpc/rpc-spec.json --cpp-server=RpcServer --cpp-server-file=src/rpc/rpcserver.h```

# How to generate ObjectBox classes
Go to ```src/obx``` folder, and run generator with ```--help``` flag for further instructions.
### Git repo:

```https://cicd.skyway.porsche.com/AEPRIL/aepril-core.git```
```git@cicd.skyway.porsche.com:AEPRIL/aepril-core.git```