#!/bin/bash

# visual effects
BOLD=`tput bold`
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

if [[ ${1} == "-r" ]]; then
    echo -e "* Removing old files..."
    rm -rf ./build/
    rm -rf ./out/*
fi

cmake -S . -B ./build/
CMAKE=$?

if [[ ${CMAKE} != 0 ]]; then
    echo -e "${RED}${BOLD}Error:  cmake (${CMAKE})${NC}"
    exit 1
fi

make -C ./build/
MAKE=$?

if [[ ${MAKE} != 0 ]]; then 
    echo -e "${RED}${BOLD}Error:  make (${MAKE})${NC}"
    exit 2
fi

echo -e "${GREEN}${BOLD}Success${NC}"