from PyQt6.QtCore import pyqtSignal, QObject
from arxml.config_provider import ConfigProvider
from arxml.query_builder import QueryBuilder
from arxml.query_handler import QueryHandler
from arxml.data_writer import DataWriter
from logic.rule_creator import RuleCreator
from common.data_types import Rule
import logging


class Worker(QObject):
    progress = pyqtSignal(str)
    message = pyqtSignal(str)
    error = pyqtSignal(str)
    exception = pyqtSignal(str)
    rule= pyqtSignal(Rule)
    finished = pyqtSignal()

    def __init__(self, model):
        super().__init__()
        self.model = model

    def emitException(self, exception, context_message):
        combined_message = f"Exception '{str(type(exception).__name__)}': {str(exception)}" \
                           f"Exception Message: {str(exception)}\n" \
                           f"Context: {context_message}"
        self.exception.emit(combined_message)


    def process(self):
        if not self.model.config_file.exists():
            self.error.emit(f'Error: "config.yaml" does not exist at required location ({self.model.config_file})')
            self.finished.emit()
        else:
            self.model.config = self.load_config(self.model.config_file)
            self.model.queries = self.build_queries(self.model.config)
            self.model.data = self.extract_data(self.model.input_arxml, self.model.queries)
            self.write_data(self.model.output_file, self.model.data)
            self.message.emit(f'{self.model.input_arxml_short}: processing done, frame specifications generated.')

        self.finished.emit()

    def load_config(self, file):
        logger = logging.getLogger()
        logger.info(f'START PROCESS - loading configuration \'{str(file)}\'')

        try:
            config_provider = ConfigProvider()
            config = config_provider.load(str(file))
        except Exception as e:
            self.emitException(e, f'reading configuration file \'{str(file)}\'')
            self.finished.emit()

        logger.info('END PROCESS - successfully finished loading configuration')
        return config

    def build_queries(self, config):
        logger = logging.getLogger()
        logger.info('START PROCESS - building queries from configuration')

        try:
            query_builder = QueryBuilder(self)
            queries = query_builder.build(config)
        except Exception as e:
            self.emitException(e, 'building queries')
            self.finished.emit()

        logger.info('END PROCESS - successfully finished building queries from configuration')
        return queries


    def extract_data(self, file, queries):
        logger = logging.getLogger()
        logger.info('START PROCESS - handling of data queries')

        try:
            query_handler = QueryHandler(self)
            data = query_handler.handle_queries(str(file), queries)
        except Exception as e:
            self.emitException(e, 'handling queries')
            self.finished.emit()


        logger.info('END PROCESS - successfully finished handling of data queries')
        return data


    def write_data(self, file, data):
        logger = logging.getLogger()
        logger.info(f'START PROCESS - writing results to \'{str(file)}\'')

        try:
            output_writer = DataWriter()
            output_writer.write_json(str(file), data)
        except Exception as e:
            self.emitException(e, f'writing results to \'{str(file)}\'')
            self.finished.emit()

        logger.info('END PROCESS - successfully finished writing results')

    def create_rule(self):
        gen = RuleCreator(self)
        rule = gen.create_rule(self.model.actual_params.mode, self.model.actual_params.rule_id, self.model.actual_params.status, self.model.actual_params.duration, self.model.actual_params.duration_type, self.model.actual_params.src_ip, self.model.actual_params.src_port, self.model.actual_params.dest_ip, self.model.actual_params.dest_port, self.model.actual_params.pdu_id, self.model.actual_params.signal_name, self.model.actual_params.new_value, self.model.actual_params.polynomial, self.model.actual_params.secret_key)
        if rule is None:
            rule = Rule()
        self.rule.emit(rule)
        self.finished.emit()
        return rule
