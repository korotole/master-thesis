import os
from pathlib import Path
import bigjson

from common.data_types import Rule


def extract_ipv6_port_protocol(address, flag):
    parts = address.split('_')
    try:
        port = int(parts[-3])
    except:
        port = -1 # port is dynamic
    protocol = parts[-2]
    if flag:  # source
        ipv6 = ':'.join(parts[3:11])
        return ipv6, port, protocol
    else:
        ipv6 = ':'.join(parts[2:10])
        return ipv6, port, protocol


class RuleCreator:
    def __init__(self, worker):
        self.worker = worker
        self.rule = None
        pass

    def create_rule(self, mode, rule_id, status, duration, duration_type, src_ip, src_port, dest_ip, dest_port, pdu_id,
                    signal_name, new_value, polynomial, secret_key):
        self.rule = Rule(mode, rule_id, status, duration, duration_type, src_ip, src_port, dest_ip, dest_port, pdu_id,
                         signal_name, None, None, new_value, polynomial, secret_key, None, None, None, None, None, None)
        if not mode:  # filtering
            return self.rule
        elif mode:  # modification
            return self.generate_specs()
        else:
            return None

    def generate_specs(self):
        found = False
        idx = 0
        directory = os.path.dirname(self.worker.model.output_file)
        file_prefix = Path(self.worker.model.input_arxml).stem + "_frame_"

        total_files = sum(1 for filename in os.listdir(directory)
                          if filename.startswith(file_prefix) and filename.endswith(".json"))

        idx = 0
        for filename in os.listdir(directory):
            if filename.startswith(file_prefix) and filename.endswith(".json"):
                file_path = os.path.join(directory, filename)
                with open(file_path, 'rb') as file:  # 'rb' for binary mode
                    # Use ijson to parse the file incrementally
                    frame_data = bigjson.load(file)
                    if found:
                        break
                    progress = ((idx + 1) / total_files) * 100
                    self.worker.progress.emit(f"Searching for signal info in {filename} ({ progress:.0f}%)")
                    found = self.find_signal_info(frame_data, self.rule.signal_name)
                    idx = idx + 1

                if found:
                    self.worker.message.emit('Signal info found.')
                    break

        return self.rule if found else None

    def find_signal_info(self, json_data, signal_name):
        source_ipv6, source_port, protocol = extract_ipv6_port_protocol(json_data['Source'], True)
        destination_ipv6, destination_port, _ = extract_ipv6_port_protocol(json_data['Destination'], False)

        for pdu_entry in json_data['Pdus']:
            pdu_id = pdu_entry['Id']

            # Check if Signals is a list or a single object
            signals = pdu_entry['Signals']
            try:
                for signal_entry in signals:
                    if signal_entry['Name'] == signal_name:
                        signal_start = signal_entry['StartPosition']
                        signal_length = signal_entry['Length']

                        crc_info = None
                        bz_info = None
                        mac_info = None
                        for other_signal in signals:
                            if other_signal['Name'].endswith('_CRC'):
                                crc_info = (other_signal['StartPosition'], other_signal['Length'])
                            elif other_signal['Name'].endswith('_BZ'):
                                bz_info = (other_signal['StartPosition'], other_signal['Length'])
                            elif other_signal['Name'].endswith('_MAC'):
                                mac_info = (other_signal['StartPosition'], other_signal['Length'])

                            self.rule.signal_start_bit = signal_start
                            self.rule.signal_length = signal_length
                            self.rule.pdu_id = pdu_id
                            self.rule.src_ip = source_ipv6
                            self.rule.dest_ip = destination_ipv6
                            self.rule.src_port = source_port
                            self.rule.dest_port = destination_port
                            if protocol == 'TCP':
                                self.rule.protocol = True
                            elif protocol == 'UDP':
                                self.rule.protocol = False

                            if crc_info and bz_info:
                                self.rule.crc_start_bit = crc_info[0]
                                self.rule.crc_length = crc_info[1]
                                self.rule.bz_start_bit = bz_info[0]
                                self.rule.bz_length = bz_info[1]

                            if mac_info:
                                self.rule.mac_start_bit = mac_info[0]
                                self.rule.mac_length = mac_info[1]

                        return True  # Signal found and info written to file
            except:
                print("exception")
                pass

        return False  # Signal not found
