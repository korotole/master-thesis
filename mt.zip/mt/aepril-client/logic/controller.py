import logging
import sys
import ipaddress
from logic.model import Model
from views.gui_view import GuiView
from views.console_view import ConsoleView
from common.data_types import Params

class Controller:
    def __init__(self, gui, screen_size, log=False):
        self.model = Model(self)
        if gui:
            self.view = GuiView(self, screen_size)
        else:
            self.view = ConsoleView()

        self.gui = gui
        self.worker = None
        self.thread = None
        self.setup_logging(log)

    def is_convertible_to_integer(self, id_str):
        try:
            int(id_str)  # Attempt to convert to integer
            return True
        except ValueError:
            return False

    def check_server_info(self):
        try:
            ipaddress.ip_address(self.model.server_ip)
            is_valid_ip = True
        except ValueError:
            is_valid_ip = False
        except TypeError:
            is_valid_ip = False

        is_valid_port = False
        if self.model.server_port is not None:  # Ensure port_str is not None
            try:
                port = int(self.model.server_port)
                is_valid_port = 0 <= port <= 65535
            except ValueError:
                is_valid_port = False

        return is_valid_ip and is_valid_port

    def generate_request(self, method=None, mode=None, rule_id=None, status=None, duration=None, duration_type=None, src_ip=None, src_port=None, dest_ip=None, dest_port=None, pdu_id=None, signal_name=None, new_value=None, polynomial=None, secret_key=None):
        if not self.check_server_info():
            self.output("Error: server ip/port is not correct, or connection was not yet established", False, True)
            return
        if method == 'upsert':
            if rule_id != '' and not self.is_convertible_to_integer(rule_id):
                self.output("Error: incorrect Server ID of rule to update is provided.", False, True)
                return
            if mode == 1:
                if signal_name is None or signal_name == '':
                    self.output("Error: 'Signal Name' must be provided.", False, True)
                    return

                if new_value is None or new_value == '':
                    self.output("Error: 'New Value' must be provided.", False, True)
                    return

                if not (self.is_convertible_to_integer(duration) or duration_type == 'inf'):
                    self.output("Error: 'Duration' must be a convertible to integer or 'inf'.", False, True)
                    return

                # If all conditions are met, process the request
                self.model.process_request(method,
                                           Params(mode, rule_id, status, duration, duration_type, src_ip, src_port,
                                                  dest_ip, dest_port, pdu_id, signal_name, new_value, polynomial,
                                                  secret_key))
            else:  # Assuming mode is "filtering"
                # Check each parameter individually and return with an error message if any are missing or empty
                if src_ip is None or src_ip == '':
                    self.output("Error: 'Source IPv6' must be provided for filtering.", False, True)
                    return

                if src_port is None or src_port == '':
                    self.output("Error: 'Source Port' must be provided for filtering.", False, True)
                    return

                if dest_ip is None or dest_ip == '':
                    self.output("Error: 'Target IPv6' must be provided for filtering.", False, True)
                    return

                if dest_port is None or dest_port == '':
                    self.output("Error: 'Target Port' must be provided for filtering.", False, True)
                    return

                if pdu_id is None or pdu_id == '':
                    self.output("Error: 'PDU ID' must be provided for filtering.", False, True)
                    return

                if not (self.is_convertible_to_integer(duration) or duration_type == 'inf'):
                    self.output("Error: 'Duration' must be convertible to integer or 'inf'.", False, True)
                    return

                # If all conditions are met, proceed with the filtering request
                self.model.process_request(method,
                                           Params(mode, rule_id, status, duration, duration_type, src_ip, src_port,
                                                  dest_ip, dest_port, pdu_id, signal_name, new_value, polynomial,
                                                  secret_key))
        # elif method == 'update':
        #     if rule_id is None or rule_id == '' or not self.is_convertible_to_integer(rule_id):
        #         self.output("Error: Server ID of rule to update must be provided.", False, True)
        #         return
        #
        #     if mode == 1:
        #         # Check if 'signal_name' is provided and valid
        #         if signal_name is None or signal_name == '':
        #             self.output("Error: 'Signal Name' must be provided for rule update.", False, True)
        #             return
        #
        #         # Check if 'new_value' is provided and valid
        #         if new_value is None or new_value == '':
        #             self.output("Error: 'New Value' must be provided for rule update.", False, True)
        #             return
        #
        #         # Check if 'duration' is convertible to integer
        #         if not self.is_convertible_to_integer(duration):
        #             self.output("Error: 'Duration' must be convertible to an integer.", False, True)
        #             return
        #
        #         # Proceed with modification request
        #         self.model.process_request(method,
        #                                    Params(mode, rule_id, status, duration, duration_type, src_ip, src_port,
        #                                           dest_ip, dest_port, pdu_id, signal_name, new_value, polynomial,
        #                                           secret_key))
        #     else:  # Assuming mode is "filtering"
        #         if any(param not in [None, ''] for param in [src_ip, src_port, dest_ip, dest_port, pdu_id]) and self.is_convertible_to_integer(duration):
        #             # Proceed with filtering request
        #             self.model.process_request(method,
        #                                        Params(mode, rule_id, status, duration, duration_type, src_ip, src_port,
        #                                               dest_ip, dest_port, pdu_id, signal_name, new_value, polynomial,
        #                                               secret_key))
        #             pass  # Replace with actual code
        #         else:
        #             self.output("Error: At least one of 'Source IPv6', 'Source Port', 'Target IPv6', 'Target Port', 'PDU ID' must be provided for rule update.", False, True)
        #             return
        elif method == 'set':
            if (rule_id is None or rule_id == '') or (rule_id != 'all' and rule_id != 'ALL' and not self.is_convertible_to_integer(rule_id)):
                self.output("Error: server ID of rule to set the status of must be provided or 'all'.", False, True)
                return
            self.model.process_request(method,
                                       Params(mode, rule_id, status, duration, duration_type, src_ip, src_port,
                                              dest_ip, dest_port, pdu_id, signal_name, new_value, polynomial,
                                              secret_key))
        elif method == 'get':
            if (rule_id is None or rule_id == '') or (rule_id != 'all' and rule_id != 'ALL' and not self.is_convertible_to_integer(rule_id)):
                self.output("Error: server ID of rule to get must be provided or 'all'.", False, True)
                return
            self.model.process_request(method,
                                       Params(mode, rule_id, status, duration, duration_type, src_ip, src_port,
                                              dest_ip, dest_port, pdu_id, signal_name, new_value, polynomial,
                                              secret_key))
            pass
        elif method == 'delete':
            if (rule_id is None or rule_id == '') or (rule_id != 'all' and rule_id != 'ALL' and not self.is_convertible_to_integer(rule_id)):
                self.output("Error: server ID of rule to delete must be provided or 'all'.", False, True)
                return
            self.model.process_request(method,
                                       Params(mode, rule_id, status, duration, duration_type, src_ip, src_port,
                                              dest_ip, dest_port, pdu_id, signal_name, new_value, polynomial,
                                              secret_key))
        elif method == 'start' or method == 'stop' or method == 'test':
            self.model.process_request(method, {})
            pass
        else:
            pass

    def set_server(self, ip, port):
        self.model.server_ip = ip
        self.model.server_port = port
        return self.check_server_info()

    def set_arxml(self, arxml):
        self.model.process_arxml(arxml)

    def output(self, msg, is_progress, is_error):
        if self.gui or is_error:
            self.view.update_output_area(msg, is_progress, is_error)
            if not self.gui:
                sys.exit()

    def setup_logging(self, enable: bool):
        logger = logging.getLogger()

        if enable:
            logging.basicConfig(
                filename='extraction.log', filemode='w', format='%(levelname)s: %(message)s')
            logger.setLevel('DEBUG')
        else:
            logger.disabled = True
