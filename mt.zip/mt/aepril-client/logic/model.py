from pathlib import Path
from PyQt6.QtCore import QThread, QTimer

from common import utils
from logic.worker import Worker
from common.data_types import Rule
import requests
import json
import ipaddress
import os


class Model:
    def __init__(self, controller):
        self.controller = controller
        self.worker = None
        # Construct the path to the config file relative to the script directory
        self.config_file = Path(os.path.dirname(os.path.abspath(__file__))).parent / 'config' / 'config.yaml'
        self.output_file = None

        self.server_ip = None
        self.server_port = None

        self.input_arxml = None
        self.actual_rule = None
        self.actual_method = None
        self.actual_params = None

        self.signal_worker_active = False
        self.signal_exception = None
        self.signal_error = None

    def process_request(self, method, params):
        if self.signal_worker_active:
            self.handle_error("Error: request processing is already in progress! Wait until it ends.")
            return

        self.actual_method = method
        self.actual_params = params

        if method == 'upsert':
            if self.controller.gui:
                self.signal_worker_active = True
                self.worker = Worker(self)
                self.thread = QThread()
                self.worker.moveToThread(self.thread)

                self.worker.progress.connect(self.handle_progress)
                self.worker.exception.connect(self.handle_error)
                self.worker.error.connect(self.handle_error)
                self.worker.message.connect(self.handle_message)
                self.worker.rule.connect(self.handle_rule)

                self.thread.started.connect(self.worker.create_rule)
                self.worker.finished.connect(self.onWorkerFinished)
                self.worker.finished.connect(self.thread.quit)
                self.worker.finished.connect(self.worker.deleteLater)
                self.thread.finished.connect(self.thread.deleteLater)

                try:
                    QTimer.singleShot(100, self.thread.start)  # 100 ms delay
                    self.thread.start()
                except Exception as e:
                    print(e)
            else:
                self.worker = Worker(self)
                rule = self.worker.create_rule()
                self.handle_rule(rule)
        elif method == 'set':
            response = self.send_request_to_server(method, {params.rule_id, params.status})
            if response:
                self.handle_message(response)
        elif method == 'get' or method == 'delete':
            response = self.send_request_to_server(method, params.rule_id)
            if response:
                self.handle_message(response)
        elif method == 'start' or method == 'stop' or method == 'test':
            response = self.send_request_to_server(method, params)
            if response:
                self.handle_message(response)
            pass
        else:
            self.handle_error("Error: unknown method.")

    def send_request_to_server(self, method, params):
        try:
            # Parse the IP address using ipaddress module
            ip = ipaddress.ip_address(self.server_ip)

            # Format the URL based on whether it's IPv4 or IPv6
            if ip.version == 6:  # IPv6 addresses need to be enclosed in square brackets
                url = f"http://[{self.server_ip}]:{self.server_port}"
            else:  # For IPv4, use the IP as it is
                url = f"http://{self.server_ip}:{self.server_port}"
        except ValueError:
            self.handle_error("Invalid IP address format.")

        headers = {'Content-Type': 'application/json'}
        payload = {
            "method": method,
            "params": params,
            "jsonrpc": "2.0",
            "id": 0,
         }

        try:
            response = requests.post(url, data=json.dumps(payload), headers=headers)
            return response.json()
        except requests.ConnectionError as e:
            self.handle_error(f"Connection error: {e}")
        except requests.Timeout:
            self.handle_error("Request timed out.")
        except requests.RequestException as e:
            self.handle_error(f"An error occurred: {e}")
        except Exception as e:
            self.handle_error(f"A general error occurred: {e}")

    def process_arxml(self, input_arxml):
        if self.signal_worker_active:
            self.handle_error("Error: .arxml processing is already in progress! Wait until it ends.")
            return

        self.input_arxml = input_arxml
        self.input_arxml_short = Path(input_arxml).name
        self.output_file = Path(os.path.dirname(os.path.abspath(__file__))).parent / 'output' /f'{Path(input_arxml).stem}' / f'{Path(input_arxml).stem}.json'

        if self.output_file.exists():
            self.handle_message(f'{Path(input_arxml).name} is already processed.')
            return
        else:
            self.output_file.parent.mkdir(parents=True, exist_ok=True)

        if self.controller.gui:
            self.signal_worker_active = True
            self.worker = Worker(self)
            self.thread = QThread()
            self.worker.moveToThread(self.thread)

            self.worker.progress.connect(self.handle_progress)
            self.worker.exception.connect(self.handle_error)
            self.worker.error.connect(self.handle_error)
            self.worker.message.connect(self.handle_message)

            self.thread.started.connect(self.worker.process)
            self.worker.finished.connect(self.onWorkerFinished)
            self.worker.finished.connect(self.thread.quit)
            self.worker.finished.connect(self.worker.deleteLater)
            self.thread.finished.connect(self.thread.deleteLater)

            try:
                QTimer.singleShot(100, self.thread.start)  # 100 ms delay
                self.thread.start()
            except Exception as e:
                print(e)
        else:
            self.worker = Worker(self)
            self.worker.process()

    def check_rule(self):
        if self.actual_rule.mac_start_bit is not None and self.actual_rule.secret_key == '':
            self.handle_error("Error: the signal is protected via AUTOSAR SecOC, but no Secret Key was provided.")
            return False
        if self.actual_rule.crc_start_bit is not None and self.actual_rule.polynomial == '':
            self.handle_error("Error: the signal is CRC protected, but no Polynomial was provided.")
            return False
        if self.actual_rule.crc_start_bit is not None and self.actual_rule.polynomial != '':
            if utils.convert_to_int_array_from_hex(self.actual_rule.polynomial) == []:
                self.handle_error("Invalid input: ensure all polynomial entries are valid hexadecimal numbers (prefixed with 0x) and separated by commas.")
                return False
        return True

    def onWorkerFinished(self):
        self.signal_worker_active = False

    def handle_message(self, msg):
        self.controller.output(msg, False, False)

    def handle_progress(self, msg):
        self.controller.output(msg, True, False)

    def handle_error(self, msg: str):
        self.controller.output(msg, False, True)

    def handle_rule(self, rule: Rule):
        self.actual_rule = rule
        if rule.mode == -1:
            self.handle_error("Error: specified signal was not found in .arxml provided.")
            return
        if not self.check_rule():
            self.handle_error("Error: the rule generated is incomplete.")
            return

        self.handle_message('Rule created successfully.')
        response = self.send_request_to_server(self.actual_method, self.actual_rule.to_dict())
        if response is not None:
            self.handle_message(response)
