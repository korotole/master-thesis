from common import utils


class Rule:
    def __init__(self, mode=-1, rule_id=-1, status=-1, duration=-1, duration_type=-1, src_ip=-1, src_port=-1, dest_ip=-1, dest_port=-1, pdu_id=-1,
               signal_name=-1, signal_start_bit=-1, signal_length=-1, new_value=-1, polynomial=-1, secret_key=-1, bz_start_bit=-1, bz_length=-1,
               crc_start_bit=-1, crc_length=-1, mac_start_bit=-1, mac_length=-1):
        self.mode = mode
        self.rule_id = rule_id
        self.status = status
        self.duration = duration
        self.duration_type = duration_type
        self.src_ip = src_ip
        self.src_port = src_port
        self.dest_ip = dest_ip
        self.dest_port = dest_port
        self.pdu_id = pdu_id
        self.signal_name = signal_name
        self.signal_start_bit = signal_start_bit
        self.signal_length = signal_length
        self.new_value = new_value
        self.polynomial = polynomial
        self.secret_key = secret_key
        self.bz_start_bit = bz_start_bit
        self.bz_length = bz_length
        self.crc_start_bit = crc_start_bit
        self.crc_length = crc_length
        self.mac_start_bit = mac_start_bit
        self.mac_length = mac_length
        self.protocol = None

        pass

    def to_dict(self):
        return {
            "mode": bool(self.mode),
            "id": utils.safe_convert_to_int(self.rule_id),
            "status": bool(self.status),
            "duration": utils.safe_convert_to_int(self.duration),
            "duration_type": str(self.duration_type),
            "src_ip": str(self.src_ip),
            "src_port": utils.safe_convert_to_int(self.src_port),
            "dest_ip": str(self.dest_ip),
            "dest_port": utils.safe_convert_to_int(self.dest_port),
            "pdu_id": utils.safe_convert_to_int(self.pdu_id),
            "signal_name": str(self.signal_name),
            "signal_start_bit": utils.safe_convert_to_int(self.signal_start_bit),
            "signal_length": utils.safe_convert_to_int(self.signal_length),
            "new_value": utils.safe_convert_to_int(self.new_value),
            "polynomial": utils.convert_to_int_array_from_hex(self.polynomial),
            "secret_key": utils.convert_to_int_array_from_hex(self.secret_key),
            "bz_start_bit": utils.safe_convert_to_int(self.bz_start_bit),
            "bz_length": utils.safe_convert_to_int(self.bz_length),
            "crc_start_bit": utils.safe_convert_to_int(self.crc_start_bit),
            "crc_length": utils.safe_convert_to_int(self.crc_length),
            "mac_start_bit": utils.safe_convert_to_int(self.mac_start_bit),
            "mac_length": utils.safe_convert_to_int(self.mac_length),
            "protocol": bool(self.protocol)
        }


class Params:
    def __init__(self, mode, rule_id, status, duration, duration_type, src_ip, src_port, dest_ip, dest_port, pdu_id,
               signal_name, new_value, polynomial, secret_key):
        self.mode = mode
        self.rule_id = rule_id
        self.status = status
        self.duration = duration
        self.duration_type = duration_type
        self.src_ip = src_ip
        self.src_port = src_port
        self.dest_ip = dest_ip
        self.dest_port = dest_port
        self.pdu_id = pdu_id
        self.signal_name = signal_name
        self.new_value = new_value
        self.polynomial = polynomial
        self.secret_key = secret_key

        pass
