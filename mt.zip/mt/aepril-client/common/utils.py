def convert_to_int_array_from_hex(input_string):
    if input_string is not None and input_string != '':
        try:
            # Split the string by commas and convert each part from hexadecimal to integer
            int_array = [int(item.strip(), 16) for item in input_string.split(',')]
            return int_array
        except ValueError:
            # Handle the case where the conversion fails
            print(
                "Invalid input: Ensure all entries are valid hexadecimal numbers (prefixed with 0x) and separated by commas.")
            return []
    return []


def safe_convert_to_int(value):
    try:
        # Attempt to convert the value to an integer
        return int(value)
    except (ValueError, TypeError):
        # Return -1 if the conversion fails
        return -1
