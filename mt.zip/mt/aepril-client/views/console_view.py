class ConsoleView:
    def __init__(self):
        pass

    def update_output_area(self, msg, is_progress, is_error):
        print(msg)