from PyQt6.QtWidgets import (QComboBox, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QLineEdit, QFileDialog,
                             QCheckBox, QButtonGroup, QSplitter, QTextEdit, QFrame, QTabWidget, QMessageBox,
                             QSizePolicy, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton)
from PyQt6.QtGui import QFont, QIcon, QTextOption
from PyQt6.QtCore import Qt
import re
import os


class GuiView(QWidget):
    def __init__(self, controller, screen_size):
        super().__init__()
        self.controller = controller
        self.screen_size = screen_size

        # Initialize user input attributes to None
        self.mode = None
        self.server_ip_entry = None
        self.server_port_entry = None
        self.duration_entry = None
        self.comboBox = None
        self.statusCheckbox = None
        self.ID_entry = None
        self.signal_name_entry = None
        self.signal_name_entry1 = None
        self.signal_name_entry2 = None
        self.source_ipv6_entry = None
        self.target_ipv6_entry = None
        self.source_port_entry = None
        self.target_port_entry = None
        self.pdu_id_entry = None
        self.new_value_entry = None
        self.polynomial_entry = None
        self.secret_key_entry = None
        self.file_name_label = None
        self.output_area = None

        self.initUI()

    def initUI(self):
        self.setWindowTitle("Automotive Ethernet Protocol Injection Logger")
        self.setWindowIcon(QIcon('config/Porsche-Logo.ico'))
        self.setFixedSize(self.screen_size.width() // 2, int(self.screen_size.height() // 2.45))

        # Overall Vertical Layout
        overall_layout = QVBoxLayout(self)

        # Server Configuration Area
        server_layout = self.create_server_layout()
        overall_layout.addLayout(server_layout)

        # Horizontal Splitter Layout for the rest of the UI
        splitter_layout = QHBoxLayout()

        left_widget = QWidget()
        left_widget.setLayout(self.createLeftLayout())

        # Output Area - QTextEdit for displaying information
        self.output_area = QTextEdit()
        self.setupOutputArea()

        # Add Widgets to Splitter Layout
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(left_widget)
        splitter.addWidget(self.output_area)
        splitter.setSizes([self.width() // 4, 3 * self.width() // 4])

        splitter_layout.addWidget(splitter)
        overall_layout.addLayout(splitter_layout)

    def create_server_layout(self):
        server_layout = QHBoxLayout()

        self.server_ip_entry = self.createLabelAndLineEdit("Server IP:", server_layout, 232, False)
        self.server_port_entry = self.createLabelAndLineEdit("Server Port:", server_layout, 40, False)
        server_layout.addStretch(1)

        server_layout.addStretch(1)
        server_layout.addWidget(self.createVerticalLine())
        server_layout.addStretch(1)

        self.createButton("Connect", self.on_connect_clicked, server_layout)
        # self.createButton("Disconnect", self.on_disconnect_clicked, server_layout)

        server_layout.addStretch(1)
        server_layout.addWidget(self.createVerticalLine())
        server_layout.addStretch(1)

        bold_font = QFont()
        bold_font.setBold(True)

        self.createButton("START", self.on_start_clicked, server_layout, font=bold_font)
        self.createButton("STOP", self.on_stop_clicked, server_layout, font=bold_font)

        return server_layout

    def createTabWidget(self):
        tab_widget = QTabWidget()
        tab_widget.addTab(self.createTab(self.addTrafficFilteringWidgets), "Traffic Filtering ↓")
        tab_widget.addTab(self.createTab(self.addSignalModificationWidgets), "Signal Modification ↓")
        tab_widget.setStyleSheet("QTabBar::tab { font: normal } QTabBar::tab:selected { font: bold }")
        tab_widget.setCurrentIndex(1)
        self.update_mode(tab_widget.currentIndex())
        # Connect the signal to update the mode
        tab_widget.currentChanged.connect(self.update_mode)

        return tab_widget

    def createTab(self, content_func):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        content_func(layout)
        return tab

    def createRadioButtonLayout(self):
        radio_button_layout = QHBoxLayout()
        self.duration_entry = self.createLabelAndLineEdit("Duration:", radio_button_layout, 47, False)

        self.comboBox = QComboBox()
        self.comboBox.setFixedWidth(46)
        self.comboBox.addItems(["cyc", "ms", "s", "m", "inf"])
        self.comboBox.currentIndexChanged.connect(self.onComboBoxChanged)
        radio_button_layout.addWidget(self.comboBox)
        radio_button_layout.addStretch(1)

        radio_button_layout.addWidget(self.createVerticalLine())
        radio_button_layout.addStretch(1)

        self.statusCheckbox = self.createCheckBox("Active", False, radio_button_layout)

        radio_button_layout.addStretch(1)
        radio_button_layout.addWidget(self.createVerticalLine())
        radio_button_layout.addStretch(1)

        self.ID_entry = self.createLabelAndLineEdit("ID:", radio_button_layout, 32, True)

        radio_button_layout.addStretch(1)
        return radio_button_layout

    def createLeftLayout(self):
        left_layout = QVBoxLayout()
        left_layout.addLayout(self.createFileSelectionLayout())
        left_layout.addWidget(self.createHorizontalLine())
        left_layout.addWidget(self.createTabWidget())
        left_layout.addLayout(self.createRadioButtonLayout())
        left_layout.addWidget(self.createHorizontalLine())
        left_layout.addStretch(1)
        left_layout.addLayout(self.createButtonLayout())
        return left_layout

    def addTrafficFilteringWidgets(self, layout):
        # Signal Name Label and Entry
        signal_name_layout = QHBoxLayout()
        self.signal_name_entry2 = self.createLabelAndLineEdit("Signal Name:", signal_name_layout)
        layout.addLayout(signal_name_layout)

        # Source IPv6
        source_ipv6_layout = QHBoxLayout()
        self.source_ipv6_entry = self.createLabelAndLineEdit("Source IPv6:", source_ipv6_layout, 232)
        layout.addLayout(source_ipv6_layout)

        # Target IPv6
        target_ipv6_layout = QHBoxLayout()
        self.target_ipv6_entry = self.createLabelAndLineEdit("Target IPv6:", target_ipv6_layout, 232)
        layout.addLayout(target_ipv6_layout)

        # Source and Target Port in the same row
        ports_layout = QHBoxLayout()
        ports_layout.addStretch(1)

        self.source_port_entry = self.createLabelAndLineEdit("Source Port:", ports_layout, 40)
        self.target_port_entry = self.createLabelAndLineEdit("Target Port:", ports_layout, 40)
        ports_layout.addSpacing(3)
        self.pdu_id_entry = self.createLabelAndLineEdit("PDU ID:", ports_layout, 29)

        layout.addLayout(ports_layout)
        layout.addStretch()

    def onComboBoxChanged(self, index):
        # Check if the selected item is "unlimited"
        if self.comboBox.currentText() == "inf":
            self.duration_entry.clear()
            self.duration_entry.setDisabled(True)
        else:
            self.duration_entry.setDisabled(False)

    def addSignalModificationWidgets(self, layout):

        signal_name_layout = QHBoxLayout()
        self.signal_name_entry1 = self.createLabelAndLineEdit("Signal Name:", signal_name_layout)
        layout.addLayout(signal_name_layout)

        new_value_layout = QHBoxLayout()
        self.new_value_entry = self.createLabelAndLineEdit("New Value:   ", new_value_layout)
        layout.addLayout(new_value_layout)

        polynomial_layout = QHBoxLayout()
        self.polynomial_entry = self.createLabelAndLineEdit("Polynomial:   ", polynomial_layout)
        layout.addLayout(polynomial_layout)

        secret_key_layout = QHBoxLayout()
        self.secret_key_entry = self.createLabelAndLineEdit("Secret Key:    ", secret_key_layout)
        layout.addLayout(secret_key_layout)

        # Add a stretch to push everything to the top
        layout.addStretch()

    def createFileSelectionLayout(self):
        file_layout = QHBoxLayout()
        self.choose_file_button = self.createButton("Choose File", self.chooseFile, file_layout, fixed_width=80)
        self.file_name_label = QLabel()
        file_layout.addWidget(self.file_name_label)
        return file_layout

    def createCheckBox(self, text, is_bold, layout):
        checkbox = QCheckBox(text)
        if is_bold:
            bold_font = QFont()
            bold_font.setBold(True)
            checkbox.setFont(bold_font)
        layout.addWidget(checkbox)
        return checkbox

    def createButtonLayout(self):
        button_layout = QHBoxLayout()
        button_actions = {
            "UPSERT": self.on_upsert_clicked,
            "SET": self.on_set_clicked,
            "GET": self.on_get_clicked,
            "DELETE": self.on_delete_clicked
        }
        for btn_text, btn_method in button_actions.items():
            self.createButton(btn_text, btn_method, button_layout, expanding=True, min_height=40)
        return button_layout

    def createLabelAndLineEdit(self, label_text, layout, width=None, is_bold=False):
        label = QLabel(label_text)
        if is_bold:
            bold_font = QFont()
            bold_font.setBold(True)
            label.setFont(bold_font)
        entry = QLineEdit()
        if width:
            entry.setFixedWidth(width)
        layout.addWidget(label)
        layout.addWidget(entry)
        return entry

    def createButton(self, text, method, layout, font=None, fixed_width=None, expanding=False, min_height=None):
        button = QPushButton(text)
        if font:
            button.setFont(font)
        if expanding:
            button.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        if min_height:
            button.setMinimumHeight(min_height)
        if fixed_width:
            button.setFixedWidth(fixed_width)
        button.clicked.connect(method)
        layout.addWidget(button)
        return button

    def createVerticalLine(self):
        line = QFrame()
        line.setFrameShape(QFrame.Shape.VLine)
        line.setFrameShadow(QFrame.Shadow.Sunken)
        return line

    def createHorizontalLine(self):
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setFrameShadow(QFrame.Shadow.Sunken)
        return line

    def setupOutputArea(self):
        courier_font = QFont("Courier New")
        courier_font.setPointSize(10)
        self.output_area.setFont(courier_font)  # Set the font for the output area
        self.output_area.setReadOnly(True)
        self.output_area.setWordWrapMode(QTextOption.WrapMode.NoWrap)
        self.output_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.output_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)

    def chooseFile(self):
        fname, _ = QFileDialog.getOpenFileName(self)
        if fname:
            # Extract the file extension
            file_extension = fname.split('.')[-1]
            # Define the list of required extensions
            required_extensions = ['arxml']  # example extensions

            # Check if the file extension is in the list of required extensions
            if file_extension.lower() in required_extensions:
                # Update the UI or perform further actions
                self.file_name_label.setText(os.path.basename(fname))
                self.file_name_label.setText(os.path.basename(fname))
                self.controller.set_arxml(fname)
            else:
                txt = "Error: selected file is not of .arxml format"
                self.update_output_area(txt, False, True)

    def update_mode(self, index):
        self.mode = index
        if index == 0:
            self.signal_name_entry = self.signal_name_entry2
        else:
            self.signal_name_entry = self.signal_name_entry1

    def update_output_area(self, msg, is_progress=False, is_error=False):
        def calculate_similarity(str1, str2):
            matching_chars = sum(c1 == c2 for c1, c2 in zip(str1, str2))
            total_chars = max(len(str1), len(str2))
            return matching_chars / total_chars if total_chars > 0 else 0

        all_text = self.output_area.toPlainText()
        lines = all_text.split('\n') if all_text else []  # Handle the initial empty case

        if is_error:
            msg = f"<span style='color: red; font-weight: bold;'>{msg}</span>"

        if is_progress and lines:
            last_line = lines[-1]
            # Remove percentage values from both strings for comparison
            pattern = re.compile(r'\(?\d+%\)')  # Modified to match the exact pattern
            last_line_no_percent = pattern.sub('', last_line).strip()
            msg_no_percent = pattern.sub('', msg).strip()

            similarity = calculate_similarity(last_line_no_percent, msg_no_percent)

            if '%' in last_line and similarity >= 0.9:
                lines[-1] = msg  # Update the last line with new progress
            else:
                lines.append(msg)  # Append a new line if it's a different message
        else:
            lines.append(msg)  # Append a new line if it's not a progress update

        updated_text = '<br>'.join(lines)
        self.output_area.setHtml(updated_text)
        self.output_area.verticalScrollBar().setValue(self.output_area.verticalScrollBar().maximum())

    def on_upsert_clicked(self):
        self.controller.generate_request('upsert', self.mode, self.ID_entry.text(), self.statusCheckbox.isChecked(),
                                         self.duration_entry.text(), self.comboBox.currentText(),
                                         self.source_ipv6_entry.text(), self.source_port_entry.text(),
                                         self.target_ipv6_entry.text(), self.target_port_entry.text(),
                                         self.pdu_id_entry.text(), self.signal_name_entry.text(),
                                         self.new_value_entry.text(), self.polynomial_entry.text(),
                                         self.secret_key_entry.text())

    def on_set_clicked(self):
        self.controller.generate_request('set', None, self.ID_entry.text(), self.statusCheckbox.isChecked())

    def on_get_clicked(self):
        self.controller.generate_request('get', None, self.ID_entry.text())

    def on_delete_clicked(self):
        self.controller.generate_request('delete', None, self.ID_entry.text())

    def on_connect_clicked(self):
        if self.controller.set_server(self.server_ip_entry.text(), self.server_port_entry.text()):
            self.controller.generate_request('test')
        else:
            self.update_output_area("Error: server ip or port is not correct", False, True)

    def on_start_clicked(self):
        if self.controller.set_server(self.server_ip_entry.text(), self.server_port_entry.text()):
            self.controller.generate_request('start')
        else:
            self.update_output_area("Error: server ip or port is not correct", False, True)

    def on_stop_clicked(self):
        if self.controller.set_server(self.server_ip_entry.text(), self.server_port_entry.text()):
            self.controller.generate_request('stop')
        else:
            self.update_output_area("Error: server ip or port is not correct", False, True)

    # def on_disconnect_clicked(self):
    #     # Method to handle Connect button click
    #     message = "Connection attempt initiated."
    #     self.output_area.append(message)  #
    #     message = "Connection attempt initiated. aghjvdckedfcuvewuld;iowvkujbdinklm"
    #     self.output_area.append(message)  #
