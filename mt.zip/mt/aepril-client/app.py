import sys
import ipaddress
import argparse
from common import utils
from PyQt6.QtWidgets import QApplication
from logic.controller import Controller

# def main():
#     app = QApplication(sys.argv)
#     screen_size = app.primaryScreen().size()
#     controller = Controller(screen_size, False)
#     controller.view.show()
#     sys.exit(app.exec())


def main():
    parser = argparse.ArgumentParser(description='JSON RPC CLI')

    # GUI mode argument
    parser.add_argument('--gui', action='store_true', help='Enable GUI mode')

    # Conditionally required arguments for non-GUI mode
    if not parser.parse_known_args()[0].gui:
        parser.add_argument('--server-ip', required=True, help='Server IP address')
        parser.add_argument('--server-port', required=True, help='Server port')
        parser.add_argument('--arxml', required=True, help='Full path to ARXML file')
        parser.add_argument('--method', required=True, choices=['start', 'stop', 'test', 'upsert', 'set', 'delete', 'get'],
                            help='JSON RPC method')
        parser.add_argument('--duration-type', choices=['cyc', 'ms', 's', 'm', 'inf'], help='Duration type')
        parser.add_argument('--duration', type=int, help='Duration (if duration_type is not inf)')
        parser.add_argument('--mode', required=True, type=int, choices=[0, 1],
                            help='Operation mode (0 for filtering, 1 for signal modification)')

        parser.add_argument('--rule-id', help='Rule ID on the server)')

        # Mode 0 arguments
        parser.add_argument('--src-ip', help='Source IP (mode 0)')
        parser.add_argument('--src-port', help='Source port (mode 0)')
        parser.add_argument('--dest-ip', help='Destination IP (mode 0)')
        parser.add_argument('--dest-port', help='Destination port (mode 0)')
        parser.add_argument('--pdu-id', help='PDU ID (mode 0)')

        # Mode 1 arguments
        parser.add_argument('--signal-name', help='Signal name (mode 1)')
        parser.add_argument('--new-value', help='New value (mode 1)')
        parser.add_argument('--secret-key', help='Secret key (optional in mode 1)')
        parser.add_argument('--polynomial', help='Polynomial (optional in mode 1)')

    args = parser.parse_args()
    try:
        validate_args(args)
    except Exception as e:
        parser.error(str(e))
        return

    # Handle GUI mode
    if args.gui:
        app = QApplication(sys.argv)
        screen_size = app.primaryScreen().size()
        controller = Controller(True, screen_size, False)
        controller.view.show()
        app.exec()
        input("Press enter to close")
    else:
        controller = Controller(False, 0, False)
        controller.set_server(args.server_ip, args.server_port)
        controller.set_arxml(args.arxml)

        request_params = {
            'method': args.method,
            'mode': args.mode,
            'rule_id': args.rule_id,  # Assuming ID is an attribute in args
            'status': args.status,  # Assuming status is a boolean attribute in args
            'duration': args.duration,  # Assuming duration is an attribute in args
            'duration_type': args.duration_type,  # Assuming duration_type is an attribute in args
            'src_ip': args.src_ip,  # Assuming src_ip is an attribute in args
            'src_port': args.src_port,  # Assuming src_port is an attribute in args
            'dest_ip': args.dest_ip,  # Assuming dest_ip is an attribute in args
            'dest_port': args.dest_port,  # Assuming dest_port is an attribute in args
            'pdu_id': args.pdu_id,  # Assuming pdu_id is an attribute in args
            'signal_name': args.signal_name,  # Assuming signal_name is an attribute in args
            'new_value': args.new_value,  # Assuming new_value is an attribute in args
            'polynomial': args.polynomial,  # Assuming polynomial is an attribute in args
            'secret_key': args.secret_key  # Assuming secret_key is an attribute in args
        }

        # Now call generate_request with the collected parameters
        if args.method == 'upsert':
            controller.generate_request(**request_params)
        if args.method == 'set':
            controller.generate_request(args.method, args.rule_id, args.status)
        if args.method == 'get' or args.method == 'delete':
            controller.generate_request(args.method, args.rule_id)
        if args.method == 'start' or args.method == 'stop' or args.method == 'test':
            controller.generate_request(args.method)


def validate_args(args):
    # todo finish sanity checks
    if args.gui:
        return
    try:
        ipaddress.ip_address(args.server_ip)
        utils.safe_convert_to_int(args.port)
    except:
        sys.exit("Error: invalid server ip or port provided.")

    if args.method == 'start' or args.method == 'stop' or args.method == 'test':
        return
    elif args.method == 'select' or args.method == 'delete':
        if utils.safe_convert_to_int(args.rule_id) == -1 and args.rule_id != 'all' and args.rule_id != 'ALL':
            sys.exit("Error: invalid rule_id provided.")
    elif args.method == 'update' or args.method == 'insert':
        if args.method == 'update' and utils.safe_convert_to_int(args.rule_id) == -1:
            sys.exit("Error: invalid rule_id provided.")
        else:
            if args.mode == 0:
                if not any([args.src_ip, args.src_port, args.dest_ip, args.dest_port, args.signal_name, args.pdu_id] and not args.duration_type):
                    sys.exit(
                        "Error: In mode 0, at least one of src_ip, src_port, dest_ip, dest_port, signal_name, pdu_id must be provided.")
            elif args.mode == 1:
                if not all([args.signal_name, args.new_value, args.duration_type]):
                    sys.exit("Error: In mode 1, SIGNAL_NAME and NEW_VALUE are mandatory.")
            else:
                sys.exit("Error: unknown mode was provided.")

    else:
        sys.exit("Error: unknown method was provided.")


if __name__ == '__main__':
    main()

