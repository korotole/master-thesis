import json
import os
from pathlib import Path

class DataWriter():

    def transform_data(self, data):
        new_frames = []

        for frame in data['Frames']:
            source = frame['Source']

            # Ensure SocketConnection is a list
            socket_connections = frame['SocketConnection']
            if not isinstance(socket_connections, list):
                socket_connections = [socket_connections]

            for socket_connection in socket_connections:
                new_frame = {
                    'Source': source,
                    'Destination': socket_connection['DestinationContainer']['Destination'],
                    'Pdus': []
                }

                # Ensure Pdus is a list
                pdus = socket_connection['Pdus'] if isinstance(socket_connection['Pdus'], list) else [
                    socket_connection['Pdus']]

                for pdu in pdus:
                    # Skip Pdu if Id is None
                    if pdu['Id'] is None:
                        continue

                    new_pdu = {
                        'Id': pdu['Id'],
                        'Signals': []
                    }

                    # Ensure Signals is a list
                    signals = pdu['PropertiesContainer']['Properties']['Signals']
                    signals = signals if isinstance(signals, list) else [signals]

                    for signal in signals:
                        # Handle null values
                        name = signal.get('Name', '-1') or '-1'
                        start_position = signal.get('StartPosition', -1)
                        start_position = start_position if start_position is not None else -1
                        length = signal.get('Length', -1)
                        length = length if length is not None else -1

                        new_signal = {
                            'Name': name,
                            'StartPosition': start_position,
                            'Length': length
                        }

                        new_pdu['Signals'].append(new_signal)

                    new_frame['Pdus'].append(new_pdu)

                new_frames.append(new_frame)

        return {'Frames': new_frames}

    def write_json(self, file: str, data: dict):
        with open(os.path.join(os.path.dirname(file), f"{Path(file).stem}_frame_orig.json"), 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        transformed_data = self.transform_data(data)
        with open(file, 'w', encoding='utf-8') as f:
            json.dump(transformed_data, f, ensure_ascii=False, indent=4)
        # Split frames into separate files
        for idx, frame in enumerate(transformed_data['Frames']):
            frame_file_name = f"{Path(file).stem}_frame_{idx+1}.json"
            frame_file_path = os.path.join(os.path.dirname(file), frame_file_name)
            with open(frame_file_path, 'w') as frame_file:
                json.dump(frame, frame_file)