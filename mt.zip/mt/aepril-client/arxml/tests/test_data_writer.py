import pytest
from pathlib import Path

from arxml.data_writer import DataWriter


@pytest.fixture
def data():
    return {
    "Frames": [
        {
            "Source": "SCB_SA_Tx_fd53_7cb8_0383_0005_0000_0000_0000_0010_42994_UDP_4",
            "SocketConnection": [
                {
                    "DestinationContainer": {
                        "Destination": "SA_Rx_ff14_0000_0000_0000_0000_0000_0000_0005_42557_UDP_4_XIX_SCB_SA_Tx_fd53_7cb8_0383_0005_0000_0000_0000_0010_42994_UDP_4"
                    },
                    "Pdus": {
                        "Id": "1343228928",
                        "PropertiesContainer": {
                            "Properties": {
                                "Signals": [
                                    {
                                        "Name": "NM_GW_KompSchutz",
                                        "StartPosition": 0,
                                        "Length": 1
                                    },
                                    {
                                        "Name": "NM_GW_Abschaltstufe_aktiv",
                                        "StartPosition": 1,
                                        "Length": 1
                                    },
                                    {
                                        "Name": "NM_GW_Transport_Mode",
                                        "StartPosition": 2,
                                        "Length": 1
                                    }]
                            }
                        }
                    }
                }]
        }]
    }



def test_write_to_json(data):
    file = Path('result.json')
    writer = DataWriter()

    writer.write_json(str(file), data)

    assert file.exists()
    file.unlink()