from typing import List
import logging
import os

from arxml.query.data_object import DataObject
from arxml.query.data_query import DataQuery
from arxml.query.data_value import DataValue


class QueryBuilder():
    p_sep = ':'
    f_sep = '>'

    def __init__(self, worker=None):
        self.logger = logging.getLogger()
        self.worker = worker

    def build(self, config: dict) -> List[DataObject]:
        data_objects = []
        total_items = len(config)
        for idx, (key, value) in enumerate(config.items()):
            data_object = self.p_object(key, value)
            data_objects.append(data_object)

            if self.worker is not None:
                # Update progress
                progress_percentage = (idx + 1) / total_items * 100
                self.worker.progress.emit(f"{os.path.basename(self.worker.model.input_arxml)}: building queries: {progress_percentage:.0f}%")
        return data_objects

    def p_object(self, name: str, values: dict) -> DataObject:
        required = {'_xpath', '_xref', '_ref'}
        p_value = required & values.keys()
        if len(p_value) != 1:
            error_msg = f'Error in QueryBuilder: The DataObject with the name \'{name}\' is missing an anchor. Valid anchors include \'_xpath\', \'_ref\', or \'_xref\'.'
            self.logger.error(error_msg)
            raise ValueError(error_msg)

        if '_xpath' in p_value:
            xpath = values['_xpath'].split(self.p_sep)[-1]
            path = DataQuery.XPath(xpath)
        elif '_xref' in p_value:
            xpath = values['_xref'].split(self.p_sep)[-1]
            path = DataQuery.XPath(xpath, True)
        else:
            ref = values['_ref'].split(self.p_sep)[-1]
            path = DataQuery.Reference(ref)

        data_values = []
        for key, value in values.items():
            if key in required:
                continue

            if isinstance(value, dict):
                data_object = self.p_object(key, value)
                data_values.append(data_object)
            else:
                data_value = self.p_value(key, value)
                data_values.append(data_value)

        return DataObject(name, path, data_values)

    def p_value(self, name: str, value: str) -> DataValue:
        try:
            query = self.p_query(value)
            return DataValue(name, query)
        except Exception as e:
            error_msg = f'Error in QueryBuilder: There was a parsing error in the query for value \'{name}\': \'{value}\'.'
            self.logger.error(error_msg, exc_info=e)
            raise ValueError(error_msg) from e

    def p_query(self, text: str) -> DataQuery:
        if self.p_sep not in text:
            path = self.get_path(text)
            return DataQuery(path)

        raw_value_format, raw_path = text.split(self.p_sep, 2)
        path = self.get_path(raw_path)

        if self.f_sep in raw_value_format:
            raw_value, raw_format = raw_value_format.split(self.f_sep)
            value = self.get_value(raw_value)
            format = self.get_format(raw_format)
        else:
            value = self.get_value(raw_value_format)
            format = DataQuery.Format.String

        return DataQuery(path, value, format)

    def get_path(self, path: str) -> DataQuery.XPath:
        illegal_character = [self.p_sep, self.f_sep]
        if any(c in illegal_character for c in path):
            error_msg = f'Error in QueryBuilder: Illegal characters found in path \'{path}\'. Paths should not contain any of the following characters: \':\', \'>\'.'
            self.logger.error(error_msg)
            raise ValueError(error_msg)

        if path[0] != '&':
            return DataQuery.XPath(path)
        else:
            if path[1] != '(':
                error_msg = f'Error in QueryBuilder: Invalid syntax in inline reference \'{path}\'. Inline references must start with \'&(\''
                self.logger.error(error_msg)
                raise ValueError(error_msg)
            return DataQuery.XPath(path, True)

    def get_value(self, value: str) -> str:
        if (value == '') or (value == 'tag') or (value == 'text'):
            return value
        elif value.startswith('@'):
            if len(value) > 1:
                return value
            else:
                error_msg = f'Error in QueryBuilder: Invalid syntax for attribute. Attribute name must be defined'
                self.logger.error(error_msg)
                raise ValueError(error_msg)

        else:
            return 'text'

    def get_format(self, format: str) -> DataQuery.Format:
        if (format == '') or (format == 'string'):
            return DataQuery.Format.String
        elif (format == 'int'):
            return DataQuery.Format.Integer
        elif (format == 'float'):
            return DataQuery.Format.Float
        else:
            return DataQuery.Format.String
