import re

from lxml import etree
from typing import Union


class AsrParser():

    def __init__(self, arxml: str):
        parser = etree.XMLParser(remove_blank_text=True)
        self.__tree = etree.parse(arxml, parser)
        self.__root = self.tree.getroot()

        # get namespace from arxml file
        AsrParser.ns = {'ar': self.__root.nsmap[None]}

        self._packages = {
            AsrParser.get_shortname(element): element
            for element in self.find_all_elements('AUTOSAR/AR-PACKAGES/AR-PACKAGE')
        }

    def get(self):
        return self

    @property
    def tree(self):
        return self.__tree

    @property
    def root(self):
        return self.__root

    @property
    def packages(self):
        return self._packages

    def find_all_elements(self, path: str) -> list:
        xpath = AsrParser.__assemble_xpath(path)
        return AsrParser.find(self.root, '//' + xpath)

    def find_reference(self, reference: str) -> etree.Element:
        ref_parts = reference.split('/')
        if (reference.startswith('/')):
            ref_parts = ref_parts[1:]

        element = self.packages[ref_parts[0]]
        if (element is None):
            return None

        for i in range(1, len(ref_parts)):
            xpath = f'.//*/ar:SHORT-NAME[text()="{ref_parts[i]}"]/..'
            element = AsrParser.__first(AsrParser.find(element, xpath))
            if (element is None):
                return None

        return element

    @staticmethod
    def __append_namespace(path: str) -> str:
        if (path.startswith('ar:')):
            return path
        return 'ar:' + path

    @classmethod
    def __assemble_xpath(cls, path: str) -> str:
        if ('/' in path):
            return '/'.join([cls.__append_namespace(part) for part in path.split('/')])

        return AsrParser.__append_namespace(path)

    @staticmethod
    def __first(list: list):
        return next(iter(list or []), None)

    @staticmethod
    def find(base: etree.Element, xpath: Union[str, etree.XPath]) -> list:
        if isinstance(xpath, etree.XPath):
            return xpath(base)
        return base.xpath(xpath, namespaces=AsrParser.ns)

    @classmethod
    def find_elements(cls, base: etree.Element, path: str) -> list:
        xpath = cls.__assemble_xpath(path)
        return cls.find(base, './/' + xpath)

    @classmethod
    def find_first_element(cls,
                           base: etree.Element,
                           path: str,
                           attribute: str = None,
                           text: str = None) -> etree.Element:

        elements = cls.find_elements(base, path)
        return cls.__first(elements)

    @classmethod
    def find_element_by_shortname(cls, base: etree.Element, path: str, name: str) -> etree.Element:
        xpath = cls.__assemble_xpath(path)
        xpath = xpath + f'/ar:SHORT-NAME[text()="{name}"]/..'
        return cls.__first(cls.find(base, './/' + xpath))

    @classmethod
    def get_shortname(cls, element: etree.Element) -> Union[str, None]:
        return cls.__first(cls.find(element, 'ar:SHORT-NAME/text()'))

    @staticmethod
    def assemble_xpath(path: str) -> str:
        xpath = re.sub(r"([\/]+)(?!$)", r'\1ar:', path)
        if xpath.startswith('/') or xpath.startswith('.'):
            return xpath
        else:
            return 'ar:' + xpath
