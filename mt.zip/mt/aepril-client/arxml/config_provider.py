import yaml
from pathlib import Path


class ConfigProvider():

    def load(self, file: str) -> dict:
        cfg_file = Path(file)
        if cfg_file.suffix != '.yaml':
            raise ValueError(
                f'invalid configuration file extension: \'{cfg_file.suffix}\' != \'.yaml\'')

        with open(str(cfg_file), 'r') as stream:
            config = yaml.safe_load(stream)

        return config

    def parse(self, text: str) -> dict:
        config = yaml.safe_load(text)

        return config
