from typing import List
from pathlib import Path
import logging

from arxml.parser import AsrParser
from arxml.handler.object_handler import ObjectHandler
from arxml.query.data_object import DataObject


class QueryHandler():

    def __init__(self, worker=None):
        self.worker = worker
        self.logger = logging.getLogger()

    def handle_queries(self, input_text: str, queries: List[DataObject]) -> dict:
        arxml = Path(input_text)
        if not arxml.exists:
            error_msg = f'Error in QueryHandler: Input file does not exist - \'{input_text}\''
            self.logger.error(error_msg)
            raise ValueError(error_msg)
        if not arxml.is_file:
            error_msg = f'Error in QueryHandler: Input is not a file - \'{input_text}\''
            self.logger.error(error_msg)
            raise ValueError(error_msg)
        if arxml.suffix != '.arxml':
            error_msg = f'Error in QueryHandler: Invalid input file extension - \'{arxml.suffix}\' != \'.arxml\''
            self.logger.error(error_msg)
            raise ValueError(error_msg)

        parser = AsrParser(str(arxml))
        object_handler = ObjectHandler(parser, self.worker)

        results = {}

        for data_object in queries:
            if (not isinstance(data_object, DataObject)):
                error_msg = f'Error in QueryHandler: Invalid root element type - \'{type(data_object)}\' is not a valid DataObject'
                self.logger.error(error_msg)
                raise TypeError(error_msg)

            results[data_object.name] = object_handler.handle(parser, data_object, None, 1)

        return results
