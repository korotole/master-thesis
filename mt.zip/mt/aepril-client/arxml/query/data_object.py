from __future__ import annotations

from typing import Union, List
import logging

from arxml.query.data_query import DataQuery
from arxml.query.data_value import DataValue


class DataObject():

    def __init__(self, name: str, path: Union[DataQuery.XPath, DataQuery.Reference],
                 values: List[Union[DataValue, DataObject]]):

        self.logger = logging.getLogger()
        self.name = name
        self.path = self.set_path(path)
        self.values = self.set_values(values)

    def set_path(self, path):
        if isinstance(path, (DataQuery.Reference, DataQuery.XPath)):
            return path
        else:
            error_msg = f'DataObject(\'{self.name}\'): path type {type(path)} is not valid. Expected types: DataQuery.XPath or DataQuery.Reference'
            self.logger.error(error_msg)
            raise TypeError(error_msg)

    def set_values(self, values):
        if type(values) is not list:
            error_msg = f'DataObject(\'{self.name}\'): provided value type ({type(values)}) should be a list'
            self.logger.error(error_msg)
            raise TypeError(error_msg)
        if not values:
            error_msg = f'DataObject(\'{self.name}\'): provided list of values should not be empty'
            self.logger.error(error_msg)
            raise ValueError(error_msg)
        if all(isinstance(x, (DataObject, DataValue)) for x in values):
            return values

        error_msg = f'DataObject(\'{self.name}\'): list must only contain DataObject or DataValue types'
        self.logger.error(error_msg, [f'{v}: {type(v)}' for v in values])
        raise ValueError(error_msg)
