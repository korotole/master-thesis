from __future__ import annotations

import logging
from enum import Enum
from typing import Union
from dataclasses import dataclass

class DataQuery():

    @dataclass
    class Reference():
        ref: str

    @dataclass
    class XPath():
        xpath: str
        is_reference: bool = False

    class Format(Enum):
        String = 0
        Integer = 1
        Float = 2

    def __init__(self,
                 path: Union[XPath, Reference],
                 value: str = 'text',
                 format: Format = Format.String):

        self.logger = logging.getLogger()
        self.path = self.set_path(path)
        self.value = self.set_value(value)
        self.format = format

    def set_value(self, value):
        if (value == 'text' or value == 'tag' or value.startswith('@')):
            return value

        error_msg = f'DataQuery: incorrect input \'{value}\'. Input must be \'tag\', \'text\', or start with \'@\'.'
        self.logger.error(error_msg)
        raise ValueError(error_msg)

    def set_path(self, path):
        if (isinstance(path, DataQuery.XPath)):
            if (':' in path.xpath):
                error_msg = f'DataQuery: XPath \'{path.xpath}\' is not valid. Namespace information should not be included in XPath'
                self.logger.error(error_msg)
                raise ValueError(error_msg)
        elif isinstance(path, DataQuery.Reference):
            if (':' in path.ref):
                error_msg = f'DataQuery: Reference \'{path.ref}\' is invalid. Namespace information should not be included in Reference'
                self.logger.error(error_msg)
                raise ValueError(error_msg)
        else:
            error_msg = f'DataQuery: path of type {type(path)} is invalid. Expected types are DataQuery.XPath or DataQuery.Reference'
            logging.error(error_msg)
            raise TypeError(error_msg)

        return path
