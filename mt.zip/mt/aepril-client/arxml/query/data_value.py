import logging
from arxml.query.data_query import DataQuery


class DataValue:
    def __init__(self, name: str, query: DataQuery):
        self.name = name
        self.logger = logging.getLogger()
        if (query is None):
            error_msg = f'DataValue(\'{self.name}\'): the type of query is invalid ({type(query)}). The query should have a DataQuery type'
            self.logger.error(error_msg)
            raise TypeError(error_msg)
        self.query = query
